# TROSC backend — staged implementation plan

Source docs: `BACKEND-REQUESTS-2.md` (round 2 frontend requests) and your
`Decisions.md` (Q1–Q10 answers). Each stage is meant to be independently
mergeable and testable — you run/test it locally, give feedback, then we
move to the next one.

## Already-fixed-in-code findings (no action taken)

Confirmed by reading the code, not just the request doc — these don't need
work, only note that the *live* API you tested against (2026-09-28) is
behind what's in this repo:

- **#1.3** (session-catalog leaking instructor email) — `getSessionCatalog`
  already `select()`s only `title description startDate duration`, no
  `instructor` field at all.
- **#4.3** (`pendingLeaves` missing from `/tracks/:id/pending`) — the
  controller already `Promise.all`s both `pendingStudents` and
  `pendingLeaves`.
- **#4.4** (orphaned deleted-user cleanup) — `scripts/cleanupOrphanedTrackReferences.js`
  already exists and is idempotent; it just hasn't been run (correctly,
  per your constraint against running repair scripts without confirmation).

## Open question for you (not answered by either doc)

`session.route.js` applies `router.use(protect)` before every route,
including `GET /sessions` — which also has `optionalAuth`, currently dead
code, since `protect` already 401s an anonymous request before `optionalAuth`
ever runs. `track.route.js`/`course.route.js` don't have this restriction —
tracks/courses are anonymously browsable, sessions currently aren't. Given
`access: 'public'` sessions are meant to be self-enrollable, should
published, public sessions be anonymously listable/viewable the same way?
This wasn't flagged as a bug in either doc, so I left it alone, but it's
worth a decision — a one-line change either way once you decide.

---

## Stage 1 — Draft-visibility policy + trusted hosts done

Q2, Q5, Q8, Q1/Q9 (docs only), Q10 (foundation only).
`src/services/policy.service.js`, session/track/course read-path fixes,
YouTube trusted hosts, `GET /v1/config/trusted-hosts`.

## Stage 2 — Public membership-array reduction (Q7) done

`src/services/policy.service.js` gained `isMemberOf`/`redactMembership`.
Fixed on: `GET /tracks` (list), `GET /tracks/:id`, `GET /tracks/popular`
(a raw aggregation pipeline - a third, previously-unnoticed instance of
the same leak, fully public), `GET /courses` (list), `GET /courses/:id`,
`GET /sessions/:id`, and the session list endpoints (studentCount/
isEnrolled added; students/progress were already stripped in stage 1).
`pendingStudents`/`pendingLeaves` on `GET /tracks/:id` had NO gate at
all before this - arguably the most serious individual finding in this
stage, worse than the "isn't populated with names" version of the
`students` leak.

Deferred to a later stage (flagged in API.md, not silently dropped):
- `GET /courses/instructor/:instructorId` and `GET /courses/track/:trackId`
  still return the raw `students` array to any caller - fixing this needs
  `tests/controllers/course.controller.test.js`'s fixtures updated first
  (they default to `published: false` and call these endpoints
  anonymously), which wasn't bundled into stage 2's diff.
- The equivalent Track/Course sub-list endpoints (`/tracks/student/:id`,
  `/courses/student/:id`) still don't apply stage 1's draft-visibility
  filter either, for the same reason the session sub-lists needed stage
  1's dedicated attention.

## Stage 3 — `createdBy` attribution (Q6) done

Added to Assignment and WeeklyTask only, per Q6's specific wording —
Track/Course/Session already have a reassignable `instructor` field and
no separate "creator" field, so there was nothing to decouple there.
`createdBy` is set once, at creation, equal to `instructor` today but
never touched again; not client-settable (Joi has no field for it, and
rejects unknown body keys outright); not required at the schema level
(existing records predate it). `scripts/backfillCreatedBy.js` is
idempotent, `--dry-run` supported, only fills missing values, never
overwrites — **not executed**, delivered ready to run when decided.
Not directly unit-tested itself (same precedent as
`cleanupOrphanedTrackReferences.js`/`reconcileTrackCourses.js`, both of
which also connect straight to `DATABASE_URL` rather than through the
app), but the model/service behavior it depends on is covered in
`tests/createdByAttribution.test.js`.

## Stage 4 — Co-instructors & current-authorization permissions (round-2 §2, Q3)

The big one — P1 in your frontend doc. Extends `policy.service.js` from
read-only (stage 1) to management permissions:

- `Track.instructors: [userId]` (co-instructors), settable by admins,
  populated on every `GET /tracks*` alongside the existing `instructor`
  (lead). (#2.2)
- `POST/PATCH /courses` accept `instructor` from admins only, same pattern
  `POST/PATCH /tracks` already has. (#2.1)
- `POST /tracks?instructor=:userId` / `GET /tracks?instructor=:userId`
  returns tracks where the user is lead OR co-instructor. (#2.6)
- Replace the ownership half of `checkOwnership` (for track/course/session/
  assignment/weekly-task mutation, grading, `GET /assignments/:id`) with a
  policy-service check: admin, OR created the item, OR is the current
  instructor of the item's course, OR is the track's lead/co-instructor.
  This is where Q3's "current role/current staff, never historical
  creation" principle actually gets enforced for management actions, not
  just reads. (#2.3)
- `POST /courses/:id/assignments`, `POST /courses/:id/weekly-tasks`: allow
  the course's current instructor, not only whoever created the course.
  (#2.4)
- A course's own instructor can attach it to a track they co-instruct,
  not only the track's lead. (#2.5)
- This is the natural home for actually wiring `createdBy` (stage 3) into
  UI/attribution display, now that it's clearly decoupled from authority.
- Tests: every combination in the `checkOwnership` replacement matrix
  (admin / creator / course instructor / track lead / track co-instructor
  / unrelated instructor), for each affected resource type and action.

## Stage 5 — Remaining round-2 items done

- **#3.2** `submissionCount`/`ungradedCount` on assignment list responses
  for staff callers (`GET /tracks|courses|sessions/:id/assignments`).
- **#4.1/#4.2** `Track.sessions`/`sessionCount` and `Track.courses`/
  `courseCount` sync on link/unlink/delete — extends the pattern
  `scripts/reconcileTrackCourses.js` already established for courses to
  sessions too, or confirms the existing script already covers it and
  just needs running (not executed here, per your constraints).
- **Submission format decision (#3.1)**: per Q1, links stay the design —
  this stage documents the allowed hosts directly in the `file` field's
  error message (referencing `GET /v1/config/trusted-hosts`) and updates
  the relevant Swagger/API.md wording so the frontend's question in round-2
  §6.1 is answered definitively in the docs, not just this conversation.

**Delivered:** `submissionCount`/`ungradedCount` for staff of each
assignment (admin or the assignment's own instructor — `isAssignmentStaff()`
in `assignment.service.js` is the single check Stage 4 swaps for the policy
rule); error messages for every URL validator now generated from
`trustedHosts.js` via `src/utils/trustedHostsMessage.js`, and a multipart
upload gets a "submissions are links" message; the four track link/unlink
functions rewritten as atomic, idempotent, self-repairing writes;
`deleteTrackCascade` works from the union of both link sides;
`scripts/reconcileTrackSessions.js` (idempotent, `--dry-run`) — **not
executed**. Root cause of the live `sessions: []` could not be pinned from
code alone: run both reconcile scripts with `--dry-run` against production to
see the real state.

## Stage 6 — Cleanup

- **#5.1** `active` field included in `GET /users?includeInactive=true`.
- **#5.2** Verify the scheduled dashboard-stats snapshot job is actually
  running in production (operational check, not a code change — the
  workflow file already exists per the roadmap).
- Any documentation/consistency loose ends surfaced by stages 2–5.

**Findings from reading the code during Stage 5 (nothing changed yet):**

- #5.1: `user.service.js#getAllUsers` already appends `.select('+active')`,
  so this is likely fixed in the repo but not on the live API that was
  tested. Remaining work is one test, optionally `active` on
  `GET /users/:id`, and the Swagger schema.
- #5.2: the workflow runs at 00:05 UTC and snapshots the period that has
  *just started*, so daily/weekly/monthly snapshots would show about zero
  new users and never finalise the finished period. Fix: pass the previous
  period's date (`date -u -d yesterday +%F`). Also verify on your side that
  `package-lock.json` is committed (`npm ci` / `cache: npm` need it), the
  workflow is on the default branch, and the `DATABASE_URL` secret is set.
  Stopgap: an admin can seed trends with `POST /dashboard-stats/snapshot`.

---

Let me know how stage 1 tests locally and I'll start stage 2.
