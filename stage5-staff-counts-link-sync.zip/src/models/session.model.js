/**
 * @swagger
 * components:
 *   schemas:
 *     Resource:
 *       type: object
 *       description: Learning resource attached to a session
 *       required:
 *         - title
 *         - url
 *       properties:
 *         title:
 *           type: string
 *           description: Title of the resource
 *           example: "JavaScript Arrays Cheat Sheet"
 *         url:
 *           type: string
 *           description: URL to access the resource
 *           format: uri
 *           example: "https://example.com/arrays-cheatsheet.pdf"
 *       example:
 *         title: "Practice Exercises PDF"
 *         url: "https://example.com/exercises.pdf"
 *
 *     Session:
 *       type: object
 *       description: Represents a learning session/class in the Trosc platform
 *       required:
 *         - title
 *         - instructor
 *       properties:
 *         _id:
 *           type: string
 *           description: Auto-generated MongoDB ObjectId
 *           example: "507f1f77bcf86cd799439031"
 *         title:
 *           type: string
 *           description: Title of the session
 *           example: "JavaScript Functions Deep Dive"
 *         description:
 *           type: string
 *           description: Detailed description of session content
 *           example: "Learn about function declarations, expressions, arrow functions, and closures"
 *         url:
 *           type: string
 *           description: Primary content link (YouTube, Drive, Zoom, etc.)
 *           format: uri
 *           example: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
 *         embedUrl:
 *           type: string
 *           description: Auto-generated YouTube embed or Google Drive preview URL
 *           example: "https://www.youtube.com/embed/dQw4w9WgXcQ"
 *         instructor:
 *           type: string
 *           description: User ID of the session instructor
 *           example: "507f1f77bcf86cd799439011"
 *         students:
 *           type: array
 *           description: >
 *             List of enrolled students. Only present in the API response
 *             when the requester can see the session's content (its
 *             instructor, an admin, or someone enrolled directly or via a
 *             parent track/course). Everyone else gets `studentCount` +
 *             `isEnrolled` instead.
 *           items:
 *             type: string
 *             example: "507f1f77bcf86cd799439012"
 *         studentCount:
 *           type: integer
 *           description: Number of directly-enrolled students (always present, for everyone)
 *           example: 30
 *         isEnrolled:
 *           type: boolean
 *           description: Whether the requesting user is enrolled in this session — directly, via a parent track, or via a parent course (always present when authenticated)
 *         tracks:
 *           type: array
 *           description: Parent track IDs this session belongs to
 *           items:
 *             type: string
 *           example: ["507f1f77bcf86cd799439021"]
 *         course:
 *           type: string
 *           description:  Parent course ObjectId (if any)
 *           example: "507f1f77bcf86cd799439041"
 *         access:
 *           type: string
 *           enum: [public, track-only, private]
 *           default: track-only
 *           example: track-only
 *         isStandalone:
 *           type: boolean
 *           description: Whether session exists independently of a track
 *           default: false
 *           example: true
 *         duration:
 *           type: integer
 *           description: Session duration in minutes
 *           minimum: 1
 *           example: 90
 *         level:
 *           type: string
 *           description: Difficulty level of the session
 *           enum: [beginner, intermediate, advanced]
 *           default: "beginner"
 *           example: "intermediate"
 *         coverImage:
 *           type: string
 *           description: Session cover image URL
 *           example: "functions-session-cover.jpg"
 *         resources:
 *           type: array
 *           description: Learning resources for this session
 *           items:
 *             $ref: '#/components/schemas/Resource'
 *         myProgress:
 *           type: object
 *           description: Only present on GET /sessions/{id} for enrolled callers. Reflects their own watched status.
 *           properties:
 *             status: { type: string, enum: [not_started, watched] }
 *             watchedAt: { type: string, format: date-time, nullable: true }
 *         published:
 *           type: boolean
 *           description: Whether session is publicly available
 *           default: false
 *           example: true
 *         startDate:
 *           type: string
 *           format: date-time
 *           description: Scheduled start date/time for live sessions
 *           example: "2025-10-20T14:00:00.000Z"
 *         endDate:
 *           type: string
 *           format: date-time
 *           description: Scheduled end date/time for live sessions
 *           example: "2025-10-20T15:30:00.000Z"
 *         createdAt:
 *           type: string
 *           format: date-time
 *           description: When the session was created
 *           example: "2025-10-18T09:15:00.000Z"
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           description: When the session was last updated
 *           example: "2025-10-19T16:45:00.000Z"
 *       example:
 *         _id: "507f1f77bcf86cd799439031"
 *         title: "JavaScript Functions Deep Dive"
 *         description: "Learn about function declarations, expressions, arrow functions, and closures"
 *         instructor:
 *           _id: "507f1f77bcf86cd799439011"
 *           name: "Basem Esam"
 *           email: "basem@example.com"
 *           role: "instructor"
 *         students: ["507f1f77bcf86cd799439012", "507f1f77bcf86cd799439013"]
 *         tracks: ["507f1f77bcf86cd799439021"]
 *         isStandalone: false
 *         duration: 90
 *         level: "intermediate"
 *         coverImage: "functions-session-cover.jpg"
 *         resources:
 *           - title: "Practice Exercises PDF"
 *             url: "https://example.com/exercises.pdf"
 *           - title: "Video Recording"
 *             url: "https://example.com/recording.mp4"
 *         published: true
 *         startDate: "2025-10-20T14:00:00.000Z"
 *         endDate: "2025-10-20T15:30:00.000Z"
 *         createdAt: "2025-10-18T09:15:00.000Z"
 *         updatedAt: "2025-10-19T16:45:00.000Z"
 *
 *     SessionCreate:
 *       type: object
 *       description: Data required to create a new session
 *       required:
 *         - title
 *       properties:
 *         title:
 *           type: string
 *           example: "JavaScript Functions Deep Dive"
 *         description:
 *           type: string
 *           example: "Learn about function declarations, expressions, arrow functions, and closures"
 *         url:
 *           type: string
 *           format: uri
 *           example: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
 *         isStandalone:
 *           type: boolean
 *           example: false
 *         duration:
 *           type: integer
 *           example: 90
 *         level:
 *           type: string
 *           enum: [beginner, intermediate, advanced]
 *           example: "intermediate"
 *         coverImage:
 *           type: string
 *           example: "functions-session-cover.jpg"
 *         resources:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/Resource'
 *         published:
 *           type: boolean
 *           example: true
 *         startDate:
 *           type: string
 *           format: date-time
 *           example: "2025-10-20T14:00:00.000Z"
 *         endDate:
 *           type: string
 *           format: date-time
 *           example: "2025-10-20T15:30:00.000Z"
 *
 *     SessionUpdate:
 *       type: object
 *       description: Data that can be updated for a session
 *       properties:
 *         title:
 *           type: string
 *           example: "Updated Session Title"
 *         description:
 *           type: string
 *           example: "Updated session description"
 *         url:
 *           type: string
 *           format: uri
 *           example: "https://drive.google.com/file/d/abc123"
 *         tracks:
 *           type: array
 *           items:
 *             type: string
 *           example: ["507f1f77bcf86cd799439021"]
 *         access:
 *           type: string
 *           enum: [public, track-only, private]
 *           example: public
 *         isStandalone:
 *           type: boolean
 *           example: true
 *         duration:
 *           type: integer
 *           example: 120
 *         level:
 *           type: string
 *           enum: [beginner, intermediate, advanced]
 *           example: "advanced"
 *         coverImage:
 *           type: string
 *           example: "new-cover-image.jpg"
 *         resources:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/Resource'
 *         published:
 *           type: boolean
 *           example: false
 *         startDate:
 *           type: string
 *           format: date-time
 *           example: "2025-10-25T10:00:00.000Z"
 *         endDate:
 *           type: string
 *           format: date-time
 *           example: "2025-10-25T12:00:00.000Z"
 *
 *     SessionResponse:
 *       type: object
 *       description: Response format for a single session
 *       properties:
 *         status:
 *           type: string
 *           example: "success"
 *         data:
 *           type: object
 *           properties:
 *             session:
 *               $ref: '#/components/schemas/Session'
 *
 *     SessionsResponse:
 *       type: object
 *       description: Response format for multiple sessions
 *       properties:
 *         status:
 *           type: string
 *           example: "success"
 *         results:
 *           type: integer
 *           example: 8
 *         total:
 *           type: integer
 *           example: 50
 *         data:
 *           type: object
 *           properties:
 *             sessions:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Session'
 */

const mongoose = require('mongoose');
const validator = require('validator');
const isTrustedHost = require('../utils/isTrustedHost');
const { trustedHostMessage } = require('../utils/trustedHostsMessage');

const resourceSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Resource title is required.'],
  },
  url: {
    type: String,
    required: [true, 'Resource URL is required.'],
    validate: {
      validator(v) {
        if (!v) return true;
        try {
          const parsed = new URL(v);
          const isAllowed = isTrustedHost(parsed.hostname);
          return isAllowed && parsed.protocol === 'https:';
        } catch {
          return false;
        }
      },
      message: trustedHostMessage('Resource URL'),
    },
  },
});

// #1.1: tracks whether an enrolled student has watched this session. One
// entry per student, kept in sync by session.service.js#setSessionProgress
// (atomic replace, mirrors weeklyTask completions).
const progressSchema = new mongoose.Schema(
  {
    student: {
      type: mongoose.Schema.ObjectId,
      ref: 'User',
      required: true,
    },
    status: {
      type: String,
      enum: ['not_started', 'watched'],
      default: 'not_started',
    },
    watchedAt: {
      type: Date,
      default: null,
    },
  },
  { _id: false },
);

const sessionSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'A session must have a title.'],
      trim: true,
    },
    description: {
      type: String,
      trim: true,
    },
    url: {
      type: String,
      trim: true,
      validate: {
        validator(v) {
          if (!v) return true;
          // #3.3/Q8: this used to have its own youtubeRegex/driveRegex
          // fast-path (which also accepted bare/http URLs, bypassing the
          // https-only rule below) ahead of the trusted-host check —
          // exactly the "conflicting list in a different file" Q8 says
          // not to have. isTrustedHost() (backed by trustedHosts.js,
          // which now includes youtube.com/youtu.be/youtube-nocookie.com)
          // is the ONE validator for every URL field in this schema, same
          // as resourceSchema.url right above.
          try {
            const parsed = new URL(v);
            return (
              isTrustedHost(parsed.hostname) && parsed.protocol === 'https:'
            );
          } catch {
            return false;
          }
        },
        message: trustedHostMessage('Session URL'),
      },
    },
    instructor: {
      type: mongoose.Schema.ObjectId,
      ref: 'User',
      required: [true, 'A session must have an instructor.'],
    },
    students: [
      {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
      },
    ],
    tracks: [
      {
        type: mongoose.Schema.ObjectId,
        ref: 'Track',
      },
    ],
    course: {
      type: mongoose.Schema.ObjectId,
      ref: 'Course',
    },
    isStandalone: {
      type: Boolean,
      default: false,
    },
    duration: {
      type: Number, // Duration in minutes
    },
    level: {
      type: String,
      enum: ['beginner', 'intermediate', 'advanced'],
      default: 'beginner',
    },
    coverImage: {
      type: String,
      default: 'https://placehold.co/800x400?text=Trosc+Session',
      validate: {
        validator(v) {
          if (!v || v === 'https://placehold.co/800x400?text=Trosc+Session')
            return true;
          if (validator.isURL(v, { require_protocol: true })) return true;
          return /^(?!.*[/\\])[a-zA-Z0-9_-]+\.(jpg|jpeg|png|webp)$/i.test(v);
        },
        message: 'Cover image must be a valid URL or image filename',
      },
    },
    resources: [resourceSchema],
    progress: [progressSchema],
    published: {
      type: Boolean,
      default: false,
    },
    access: {
      type: String,
      enum: ['public', 'track-only', 'private'],
      default: 'track-only',
    },
    startDate: {
      type: Date,
    },
    endDate: {
      type: Date,
    },
  },
  {
    timestamps: true, // Handles createdAt and updatedAt automatically
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  },
);

// For filtering by track
sessionSchema.index({ tracks: 1 });
// For filtering by course
sessionSchema.index({ course: 1 });
// For filtering by instructor
sessionSchema.index({ instructor: 1 });
// For published + level filtering
sessionSchema.index({ published: 1, level: 1 });

// Q7: matches Track/Course's existing studentCount virtual — lets list/
// detail responses report how many students are enrolled without ever
// exposing the raw `students` array to a caller who isn't authorized to
// see it (src/services/policy.service.js#redactMembership).
sessionSchema.virtual('studentCount').get(function studentCount() {
  return this.students ? this.students.length : 0;
});

sessionSchema.pre('save', function setIsStandalone(next) {
  // Auto-set isStandalone based on relationships
  this.isStandalone = !this.tracks?.length && !this.course;
  next();
});

// Middleware to automatically populate the instructor
sessionSchema.pre(/^find/, function populateInstructor(next) {
  this.populate({
    path: 'instructor',
    select: 'name email role', // Select only the fields you need
  });
  next();
});

const Session = mongoose.model('Session', sessionSchema);

module.exports = Session;
