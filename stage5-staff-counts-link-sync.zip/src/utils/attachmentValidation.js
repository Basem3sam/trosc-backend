const Joi = require('joi');

// Free hosting services Trosc uses
const isTrustedHost = require('./isTrustedHost');
const { trustedHostMessage } = require('./trustedHostsMessage');

const attachmentValidation = Joi.array()
  .items(
    Joi.string()
      .uri()
      .custom((value, helpers) => {
        if (!value) return value;

        try {
          const url = new URL(value);
          const isAllowedHost = isTrustedHost(url.hostname);

          if (!isAllowedHost || url.protocol !== 'https:') {
            return helpers.error('any.invalid');
          }

          // Block dangerous file extensions
          const dangerous =
            /\.(exe|bat|cmd|sh|msi|dmg|apk|jar|ps1|vbs|wsf|hta|scr|pif|com)/i;
          if (dangerous.test(url.pathname)) {
            return helpers.error('attachment.dangerous');
          }

          return value;
        } catch {
          return helpers.error('any.invalid');
        }
      }, 'Attachment URL validation')
      .messages({
        'any.invalid': trustedHostMessage('Attachment'),
        'attachment.dangerous':
          'Executable files are not allowed as attachments',
      }),
  )
  .max(10) // Prevent abuse
  .optional()
  .messages({
    'array.max': 'Maximum 10 attachments allowed',
  });

module.exports = attachmentValidation;
