/**
 * @swagger
 * tags:
 *   - name: Sessions
 *     description: Learning session management and student enrollment
 */

/**
 * @swagger
 * /sessions:
 *   post:
 *     operationId: createSession
 *     summary: Create a new learning session
 *     description: Create a new session (admin and instructors only). An admin may set `instructor`; it must be an active user with role instructor or admin (400 otherwise).
 *     tags: [Sessions]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/SessionCreate'
 *     responses:
 *       201:
 *         description: Session created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SessionResponse'
 *       400:
 *         $ref: '#/components/responses/ValidationError'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         $ref: '#/components/responses/Forbidden'
 *
 *   get:
 *     operationId: getAllSessions
 *     summary: Get all sessions
 *     description: |
 *       Retrieve all sessions with filtering and pagination.
 *       **Note:** The list view unconditionally omits `url`, `embedUrl`, and `resources`.
 *       Full content is only returned in `GET /:id` for enrolled users.
 *       Supports MongoDB-style query filters, e.g.
 *       `?level=intermediate&published=true`.
 *     tags: [Sessions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: page
 *         in: query
 *         schema:
 *           type: integer
 *           default: 1
 *       - name: limit
 *         in: query
 *         schema:
 *           type: integer
 *           default: 10
 *       - name: level
 *         in: query
 *         schema:
 *           type: string
 *           enum: [beginner, intermediate, advanced]
 *       - name: published
 *         in: query
 *         schema:
 *           type: boolean
 *     responses:
 *       200:
 *         description: List of sessions retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SessionsResponse'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 */

/**
 * @swagger
 * /sessions/{id}:
 *   get:
 *     operationId: getSessionById
 *     summary: Get a specific session by ID
 *     description: |
 *       Retrieve detailed information about a session.
 *       `url`, `embedUrl`, and `resources` are stripped if the caller is
 *       not enrolled in the session, its parent track, or its parent course.
 *       Enrolled callers also get `myProgress: { status, watchedAt }`
 *       reflecting their own watched status (see PUT /sessions/{id}/progress).
 *     tags: [Sessions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Session details retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SessionResponse'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *
 *   patch:
 *     operationId: updateSessionById
 *     summary: Update a session
 *     description: Update session information (admin and instructors only). A new `instructor` must be an active user with role instructor or admin (400 otherwise).
 *     tags: [Sessions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/SessionUpdate'
 *     responses:
 *       200:
 *         description: Session updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SessionResponse'
 *       400:
 *         $ref: '#/components/responses/ValidationError'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         $ref: '#/components/responses/Forbidden'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *
 *   delete:
 *     operationId: deleteSessionById
 *     summary: Delete a session
 *     description: Permanently delete a session (admin and instructors only). Instructors can only delete sessions they currently manage (the session's instructor, its course's instructor, or lead/co-instructor of a track it belongs to).
 *     tags: [Sessions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       204:
 *         description: Session deleted successfully
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         $ref: '#/components/responses/Forbidden'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 */

/**
 * @swagger
 * /sessions/{id}/students:
 *   post:
 *     operationId: addStudentToSession
 *     summary: Add student to session
 *     description: Enroll a student in a session (admin and instructors only)
 *     tags: [Sessions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - studentId
 *             properties:
 *               studentId:
 *                 type: string
 *     responses:
 *       200:
 *         description: Student added to session successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SessionResponse'
 *       400:
 *         description: Student already enrolled in this session
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         $ref: '#/components/responses/Forbidden'
 *       404:
 *         description: Session not found
 */

/**
 * @swagger
 * /sessions/{id}/students/{studentId}:
 *   delete:
 *     operationId: removeStudentFromSession
 *     summary: Remove student from session
 *     description: Remove a student from a session (admin and instructors only)
 *     tags: [Sessions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *           example: "507f1f77bcf86cd799439031"
 *       - name: studentId
 *         in: path
 *         required: true
 *         description: MongoDB ID of the student to remove
 *         schema:
 *           type: string
 *           example: "507f1f77bcf86cd799439012"
 *     responses:
 *       200:
 *         description: Student removed from session successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SessionResponse'
 *       400:
 *         description: Student is not enrolled in this session
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         $ref: '#/components/responses/Forbidden'
 *       404:
 *         description: Session or student not found
 */

/**
 * @swagger
 * /sessions/instructor/{instructorId}:
 *   get:
 *     operationId: getSessionsByInstructor
 *     summary: Get sessions by instructor
 *     tags: [Sessions]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - name: instructorId
 *         in: path
 *         required: true
 *         schema: { type: string }
 *       - name: page
 *         in: query
 *         schema: { type: integer, default: 1 }
 *       - name: limit
 *         in: query
 *         schema: { type: integer, default: 10 }
 *     responses:
 *       200:
 *         description: List of sessions
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SessionsResponse'
 *       404: { description: Instructor not found }
 *
 * /sessions/track/{trackId}:
 *   get:
 *     operationId: getSessionsByTrack
 *     summary: Get sessions by track
 *     tags: [Sessions]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - name: trackId
 *         in: path
 *         required: true
 *         schema: { type: string }
 *       - name: page
 *         in: query
 *         schema: { type: integer, default: 1 }
 *       - name: limit
 *         in: query
 *         schema: { type: integer, default: 10 }
 *     responses:
 *       200:
 *         description: List of sessions
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SessionsResponse'
 *       404: { description: Track not found }
 *
 * /sessions/student/{studentId}:
 *   get:
 *     operationId: getSessionsByStudent
 *     summary: Get sessions by student enrollment
 *     description: Returns sessions a student is enrolled in. Admin can view any student; students can only view themselves. A session that was unpublished after enrolling is hidden unless the caller manages it or is an admin; `students`/`progress` are replaced by `isEnrolled`/`studentCount`.
 *     tags: [Sessions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: studentId
 *         in: path
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: List of sessions
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SessionsResponse'
 *       401: { $ref: '#/components/responses/Unauthorized' }
 *       403: { $ref: '#/components/responses/Forbidden' }
 *
 * /sessions/{id}/enroll-me:
 *   post:
 *     operationId: enrollMeInSession
 *     summary: Self-enroll in a session
 *     tags: [Sessions]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Enrolled successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SessionResponse'
 *       400: { description: Already enrolled }
 *       401: { $ref: '#/components/responses/Unauthorized' }
 *       403: { description: Track-only session without membership }
 *       404: { $ref: '#/components/responses/NotFound' }
 *
 * /sessions/{id}/leave-me:
 *   delete:
 *     operationId: leaveMeFromSession
 *     summary: Leave a session
 *     tags: [Sessions]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Left successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SessionResponse'
 *       400: { description: Not enrolled }
 *       401: { $ref: '#/components/responses/Unauthorized' }
 *       404: { $ref: '#/components/responses/NotFound' }
 */

/**
 * @swagger
 * /sessions/{id}/assignments:
 *   post:
 *     operationId: createSessionAssignment
 *     summary: Create an assignment for a standalone session
 *     description: Admin, the parent session's current instructor, or a lead/co-instructor of a track it belongs to. The assignment's `instructor` is set to the session's current instructor; `createdBy` is the caller.
 *     tags: [Assignments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *           example: "507f1f77bcf86cd799439031"
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/AssignmentCreate'
 *     responses:
 *       201:
 *         description: Assignment created
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status: { type: string, example: success }
 *                 data:
 *                   type: object
 *                   properties:
 *                     assignment:
 *                       $ref: '#/components/schemas/Assignment'
 *       400:
 *         $ref: '#/components/responses/ValidationError'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         $ref: '#/components/responses/Forbidden'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 */

/**
 * @swagger
 * /sessions/{id}/assignments:
 *   get:
 *     operationId: getSessionAssignments
 *     summary: Get all assignments for a standalone session
 *     description: >
 *       Each assignment includes `mySubmission` — the requesting user's own
 *       submission, or null if they haven't submitted. Accessible to admins,
 *       any instructor, or a student enrolled in the session. Everyone who can
 *       manage the assignment (an admin, the parent's current instructor, or
 *       a lead/co-instructor of its track) also gets `submissionCount` and
 *       `ungradedCount` on each assignment (counts only - never other
 *       students' files or grades).
 *     tags: [Assignments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *           example: "507f1f77bcf86cd799439031"
 *     responses:
 *       200:
 *         description: List of assignments
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status: { type: string, example: success }
 *                 results: { type: integer, example: 1 }
 *                 data:
 *                   type: object
 *                   properties:
 *                     assignments:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/Assignment'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         description: Only enrolled students can view this session's assignments
 *       404:
 *         $ref: '#/components/responses/NotFound'
 */

/**
 * @swagger
 * /sessions/{id}/reviews:
 *   post:
 *     operationId: createSessionReview
 *     summary: Submit a review for a session
 *     description: Only students currently enrolled in the session may review it (one review per student per session).
 *     tags: [Reviews]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *           example: "507f1f77bcf86cd799439031"
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [rating, content]
 *             properties:
 *               rating:
 *                 type: integer
 *                 minimum: 1
 *                 maximum: 5
 *                 example: 5
 *               content:
 *                 type: string
 *                 example: "Clear explanation, great pacing."
 *     responses:
 *       201:
 *         description: Review created
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status: { type: string, example: success }
 *                 data:
 *                   type: object
 *                   properties:
 *                     review:
 *                       $ref: '#/components/schemas/Review'
 *       400:
 *         description: Already reviewed / validation error
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         description: Only enrolled students can review
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *
 *   get:
 *     security: []
 *     operationId: getSessionReviews
 *     summary: Get reviews for a session
 *     description: Public endpoint. Supports the standard pagination query params.
 *     tags: [Reviews]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *           example: "507f1f77bcf86cd799439031"
 *       - name: page
 *         in: query
 *         schema: { type: integer, default: 1 }
 *       - name: limit
 *         in: query
 *         schema: { type: integer, default: 10 }
 *     responses:
 *       200:
 *         description: List of reviews
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status: { type: string, example: success }
 *                 results: { type: integer, example: 5 }
 *                 data:
 *                   type: object
 *                   properties:
 *                     reviews:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/Review'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 */

/**
 * @swagger
 * /sessions/{id}/reviews/{reviewId}:
 *   delete:
 *     operationId: deleteSessionReview
 *     summary: Delete a session review
 *     description: The review's own author, or an admin, may delete it.
 *     tags: [Reviews]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema: { type: string, example: "507f1f77bcf86cd799439031" }
 *       - name: reviewId
 *         in: path
 *         required: true
 *         schema: { type: string, example: "6713b5ac12ef4567890a8888" }
 *     responses:
 *       204: { description: Deleted successfully }
 *       401: { $ref: '#/components/responses/Unauthorized' }
 *       403: { $ref: '#/components/responses/Forbidden' }
 *       404: { $ref: '#/components/responses/NotFound' }
 */

/**
 * @swagger
 * /sessions/{id}/progress:
 *   put:
 *     operationId: setSessionProgress
 *     summary: Mark a session as watched for the current user
 *     description: Enrolled students only (directly, via a parent track, or via a parent course).
 *     tags: [Sessions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema: { type: string, example: "507f1f77bcf86cd799439031" }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [status]
 *             properties:
 *               status: { type: string, enum: [watched], example: watched }
 *     responses:
 *       200:
 *         description: Progress recorded
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status: { type: string, example: success }
 *                 data:
 *                   type: object
 *                   properties:
 *                     myProgress:
 *                       type: object
 *                       properties:
 *                         status: { type: string, enum: [not_started, watched] }
 *                         watchedAt: { type: string, format: date-time, nullable: true }
 *       400:
 *         $ref: '#/components/responses/ValidationError'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         description: Only enrolled students can track progress on this session
 *       404:
 *         $ref: '#/components/responses/NotFound'
 */

const express = require('express');
const AppError = require('../../utils/AppError');
const reviewRouter = require('./review.route');
const resourceAssignmentRouter = require('./resourceAssignment.route');
const sessionController = require('../../controllers/session.controller');
const {
  protect,
  restrictTo,
  requireManage,
  optionalAuth,
} = require('../../middlewares/auth.middleware');
const validateMiddleware = require('../../middlewares/validate.middleware');
const {
  createSessionValidation,
  updateSessionValidation,
  sessionIdValidation,
  addStudentValidation,
  studentIdParamValidation,
  setProgressValidation,
} = require('../../validations/session.validation');
const { authLimiter } = require('../../middlewares/rateLimit.middleware');

const router = express.Router();

// Protect all routes
router.use(protect);

// ===================================================================
// 📚 MAIN SESSION ROUTES
// ===================================================================

router
  .route('/')
  .post(
    restrictTo('admin', 'instructor'),
    validateMiddleware(createSessionValidation),
    sessionController.createSession,
  )
  .get(optionalAuth, sessionController.getAllSessions);

// ===================================================================
// 🔍 FILTERING ROUTES
// ===================================================================

router.get(
  '/instructor/:instructorId',
  sessionController.getSessionsByInstructor,
);

router.get('/track/:trackId', sessionController.getSessionsByTrack);

router.post('/:id/enroll-me', authLimiter, protect, sessionController.enrollMe);

router.delete('/:id/leave-me', authLimiter, protect, sessionController.leaveMe);

router
  .route('/:id')
  .get(
    validateMiddleware(sessionIdValidation, 'params'),
    sessionController.getSession,
  )
  .patch(
    restrictTo('admin', 'instructor'),
    validateMiddleware(sessionIdValidation, 'params'),
    requireManage({ resource: 'session' }),
    validateMiddleware(updateSessionValidation),
    sessionController.updateSession,
  )
  .delete(
    restrictTo('admin', 'instructor'),
    validateMiddleware(sessionIdValidation, 'params'),
    requireManage({ resource: 'session' }),
    sessionController.deleteSession,
  );

// ===================================================================
// 👥 STUDENT MANAGEMENT ROUTES
// ===================================================================

router
  .route('/:id/students')
  .post(
    restrictTo('admin', 'instructor'),
    validateMiddleware(sessionIdValidation, 'params'),
    requireManage({ resource: 'session' }),
    validateMiddleware(addStudentValidation),
    sessionController.addStudent,
  );

router
  .route('/:id/students/:studentId')
  .delete(
    restrictTo('admin', 'instructor'),
    validateMiddleware(sessionIdValidation, 'params'),
    validateMiddleware(studentIdParamValidation, 'params'),
    requireManage({ resource: 'session' }),
    sessionController.removeStudent,
  );

router.put(
  '/:id/progress',
  validateMiddleware(sessionIdValidation, 'params'),
  validateMiddleware(setProgressValidation),
  sessionController.setSessionProgress,
);

router.get(
  '/student/:studentId',
  protect,
  (req, res, next) => {
    if (req.user.role !== 'admin' && req.params.studentId !== req.user.id) {
      return next(new AppError('You can only view your own enrollments', 403));
    }
    next();
  },
  sessionController.getSessionsByStudent,
);

router.use('/:id/reviews', reviewRouter('session'));
router.use('/:id/assignments', resourceAssignmentRouter('session'));

module.exports = router;
