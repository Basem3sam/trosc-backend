const User = require('../models/user.model');
const Track = require('../models/track.model');
const Course = require('../models/course.model');
const Session = require('../models/session.model');
const AppError = require('../utils/AppError');
const Email = require('../utils/Email');
const runInBackground = require('../utils/runInBackground');
const cascade = require('./cascade.service');
const { recordActivity } = require('./activityLog.service');

exports.enrollStudentInTrack = async (trackId, studentId) => {
  const track = await Track.findById(trackId);
  if (!track) {
    throw new AppError('No track found with that ID', 404);
  }

  // Prevent duplicate enrollment
  if (track.students.some((id) => id.toString() === studentId)) {
    throw new AppError('Student is already enrolled in this track', 400);
  }

  const updatedTrack = await Track.findByIdAndUpdate(
    trackId,
    { $addToSet: { students: studentId } },
    { new: true, runValidators: true },
  );

  // Keep User.enrolledTracks in sync
  await cascade.syncUserEnrollments(studentId, trackId);

  return updatedTrack;
};

exports.removeStudentFromTrack = async (trackId, studentId) => {
  const track = await Track.findById(trackId);
  if (!track) throw new AppError('No track found with that ID', 404);
  if (!track.students.some((id) => id.toString() === studentId)) {
    throw new AppError('Student is not enrolled in this track', 400);
  }

  track.students.pull(studentId);
  await track.save();

  await cascade.unsyncUserEnrollments(studentId, trackId);

  return track;
};

exports.enrollMeInTrack = async (trackId, userId) => {
  // One-track-only rule: cannot be in or pending in any other track
  const userDoc = await User.findById(userId).select('enrolledTrack');
  if (userDoc.enrolledTrack && userDoc.enrolledTrack.toString() !== trackId) {
    throw new AppError(
      'You can only apply to one track at a time. Leave your current track first.',
      400,
    );
  }
  const existingPending = await Track.findOne({
    pendingStudents: userId,
    _id: { $ne: trackId },
  });
  if (existingPending) {
    throw new AppError('You can only apply to one track at a time...', 400);
  }

  const track = await Track.findById(trackId);
  if (!track) throw new AppError('No track found with that ID', 404);
  if (!track.published)
    throw new AppError('This track is not open for enrollment', 400);

  if (track.students.some((id) => id.toString() === userId)) {
    throw new AppError('You are already enrolled in this track', 400);
  }

  if (track.pendingStudents.some((id) => id.toString() === userId)) {
    throw new AppError('Your application is already pending approval', 400);
  }

  track.pendingStudents.push(userId);
  await track.save();

  recordActivity({
    userId,
    action: 'requested_track_enrollment',
    targetModel: 'Track',
    targetId: trackId,
  });

  return track;
};

exports.approveStudentInTrack = async (trackId, studentId) => {
  const track = await Track.findById(trackId);
  if (!track) throw new AppError('No track found with that ID', 404);

  if (!track.pendingStudents.some((id) => id.toString() === studentId)) {
    throw new AppError('Student is not pending in this track', 400);
  }

  const claimed = await User.findOneAndUpdate(
    { _id: studentId, enrolledTrack: null },
    { $set: { enrolledTrack: trackId } },
    { new: true },
  );
  if (!claimed) {
    const user = await User.findById(studentId).select('enrolledTrack');
    if (user.enrolledTrack?.toString() !== trackId) {
      throw new AppError('Student is already enrolled in another track', 400);
    }
  }

  track.pendingStudents.pull(studentId);
  track.students.push(studentId);
  await track.save();

  await cascade.syncUserEnrollments(studentId, trackId);

  recordActivity({
    userId: studentId,
    action: 'approved_track_enrollment',
    targetModel: 'Track',
    targetId: trackId,
  });

  return track;
};

exports.rejectStudentInTrack = async (trackId, studentId) => {
  const track = await Track.findById(trackId);
  if (!track) throw new AppError('No track found with that ID', 404);

  if (!track.pendingStudents.some((id) => id.toString() === studentId)) {
    throw new AppError('Student is not pending in this track', 400);
  }

  track.pendingStudents.pull(studentId);
  await track.save();
  return track;
};

exports.requestLeaveTrack = async (trackId, studentId) => {
  const track = await Track.findById(trackId);
  if (!track) throw new AppError('No track found with that ID', 404);
  if (!track.students.some((id) => id.toString() === studentId)) {
    throw new AppError('You are not enrolled in this track', 400);
  }
  if (track.pendingLeaves.some((id) => id.toString() === studentId)) {
    throw new AppError('Your leave request is already pending', 400);
  }

  track.pendingLeaves.push(studentId);
  await track.save();
  return track;
};

exports.approveLeaveTrack = async (trackId, studentId) => {
  const track = await Track.findById(trackId);
  if (!track) throw new AppError('No track found with that ID', 404);
  if (!track.pendingLeaves.some((id) => id.toString() === studentId)) {
    throw new AppError('No pending leave request found', 400);
  }

  track.pendingLeaves.pull(studentId);
  track.students.pull(studentId);
  await track.save();

  await cascade.unsyncUserEnrollments(studentId, trackId);

  return track;
};

exports.rejectLeaveTrack = async (trackId, studentId) => {
  const track = await Track.findById(trackId);
  if (!track) throw new AppError('No track found with that ID', 404);
  if (!track.pendingLeaves.some((id) => id.toString() === studentId)) {
    throw new AppError('No pending leave request found', 400);
  }

  track.pendingLeaves.pull(studentId);
  await track.save();
  return track;
};

exports.getPendingStudents = async (trackId) => {
  const track = await Track.findById(trackId)
    .populate('pendingStudents', 'name email photo role')
    .select('pendingStudents title');
  if (!track) throw new AppError('No track found with that ID', 404);
  return track.pendingStudents;
};

exports.getPendingLeaves = async (trackId) => {
  const track = await Track.findById(trackId)
    .populate('pendingLeaves', 'name email photo role')
    .select('pendingLeaves title');
  if (!track) throw new AppError('No track found with that ID', 404);
  return track.pendingLeaves;
};

// ============================
// COURSE ENROLLMENT
// ============================

exports.enrollInCourse = async (userId, courseId) => {
  const course = await Course.findById(courseId);
  if (!course) throw new AppError('Course not found', 404);

  // Fast-path check — not the source of truth. The atomic update below is
  // what actually closes the race between two concurrent enroll requests;
  // this just avoids running the access/prerequisite checks below for the
  // common non-racing case of "already enrolled."
  if (course.students.some((id) => id.toString() === userId)) {
    throw new AppError('You are already enrolled in this course', 400);
  }

  if (course.access === 'private') {
    throw new AppError(
      'This course requires instructor approval. You cannot self-enroll.',
      403,
    );
  }

  if (course.access === 'track-only') {
    if (!course.track) {
      throw new AppError('This course is not associated with any track', 400);
    }
    const track = await Track.findById(course.track);
    if (!track || !track.students.some((id) => id.toString() === userId)) {
      throw new AppError(
        'You must be enrolled in the parent track to access this course',
        403,
      );
    }
  }

  // Prerequisites check
  if (course.prerequisites?.length > 0) {
    const user = await User.findById(userId).select('enrolledCourses');
    const completed = user.enrolledCourses.map((id) => id.toString());
    const missing = course.prerequisites.filter(
      (prereq) => !completed.includes(prereq.toString()),
    );
    if (missing.length > 0) {
      throw new AppError(
        `You must complete prerequisites before enrolling. Missing: ${missing.length}`,
        403,
      );
    }
  }

  // Atomic: only matches (and only then $addToSet's) if userId isn't
  // already in students. Closes the race the fast-path check above can't
  // — two concurrent requests can no longer both pass a check then both
  // push; only one $ne match can succeed.
  const updatedCourse = await Course.findOneAndUpdate(
    { _id: courseId, students: { $ne: userId } },
    { $addToSet: { students: userId } },
    { new: true, runValidators: true },
  );

  if (!updatedCourse) {
    throw new AppError('You are already enrolled in this course', 400);
  }

  const user = await User.findByIdAndUpdate(userId, {
    $addToSet: { enrolledCourses: courseId },
  });

  // Confirmation email: started but not awaited, so a slow or failing mail
  // provider can neither delay nor fail enrollment. A failure is only logged.
  const courseUrl = `${process.env.FRONTEND_URL}/courses/${courseId}`;
  runInBackground('Enrollment confirmation email', { userId, courseId }, () =>
    new Email(user, courseUrl).sendEnrollmentConfirmation(updatedCourse.title),
  );

  recordActivity({
    userId,
    action: 'enrolled_in_course',
    targetModel: 'Course',
    targetId: courseId,
  });

  return updatedCourse;
};

exports.leaveCourse = async (userId, courseId) => {
  const course = await Course.findById(courseId);
  if (!course) throw new AppError('Course not found', 404);
  if (!course.students.some((id) => id.toString() === userId)) {
    throw new AppError('You are not enrolled in this course', 400);
  }

  course.students.pull(userId);
  await course.save();
  await User.findByIdAndUpdate(userId, {
    $pull: { enrolledCourses: courseId },
  });

  recordActivity({
    userId,
    action: 'left_course',
    targetModel: 'Course',
    targetId: courseId,
  });

  return course;
};

// ============================
// SESSION ENROLLMENT
// ============================

exports.enrollInSession = async (userId, sessionId) => {
  const session = await Session.findById(sessionId);
  if (!session) throw new AppError('Session not found', 404);

  if (session.students.some((id) => id.toString() === userId)) {
    throw new AppError('You are already enrolled in this session', 400);
  }

  if (session.access === 'private') {
    throw new AppError(
      'This session requires instructor approval. You cannot self-enroll.',
      403,
    );
  }

  if (session.access === 'track-only') {
    const userTracks = await Track.find({ students: userId }).select('_id');
    const userTrackIds = userTracks.map((t) => t._id.toString());
    const inTrack = session.tracks?.some((t) =>
      userTrackIds.includes(t.toString()),
    );

    let inCourse = false;
    if (session.course) {
      const course = await Course.findById(session.course);
      inCourse = course?.students.some((id) => id.toString() === userId);
    }

    if (!inTrack && !inCourse) {
      throw new AppError(
        'You must be enrolled in the parent track or course to access this session',
        403,
      );
    }
  }

  // Atomic: mirrors enrollInCourse's fix above — only matches (and only
  // then $addToSet's) if userId isn't already in students, closing the
  // race that the earlier check-then-push pattern couldn't.
  const updatedSession = await Session.findOneAndUpdate(
    { _id: sessionId, students: { $ne: userId } },
    { $addToSet: { students: userId } },
    { new: true, runValidators: true },
  );

  if (!updatedSession) {
    throw new AppError('You are already enrolled in this session', 400);
  }

  await User.findByIdAndUpdate(userId, {
    $addToSet: { enrolledSessions: sessionId },
  });

  recordActivity({
    userId,
    action: 'enrolled_in_session',
    targetModel: 'Session',
    targetId: sessionId,
  });

  return updatedSession;
};

exports.leaveSession = async (userId, sessionId) => {
  const session = await Session.findById(sessionId);
  if (!session) throw new AppError('Session not found', 404);
  if (!session.students.some((id) => id.toString() === userId)) {
    throw new AppError('You are not enrolled in this session', 400);
  }

  session.students.pull(userId);
  await session.save();
  await User.findByIdAndUpdate(userId, {
    $pull: { enrolledSessions: sessionId },
  });

  recordActivity({
    userId,
    action: 'left_session',
    targetModel: 'Session',
    targetId: sessionId,
  });

  return session;
};
