const crypto = require('crypto');
const User = require('../models/user.model');
const AppError = require('../utils/AppError');
const Email = require('../utils/Email');
const signToken = require('../utils/generateToken');
const runInBackground = require('../utils/runInBackground');
const { recordActivity } = require('./activityLog.service');

// Long/short session durations used by login's "remember me" option.
// Kept in one place so the JWT and the cookie (set in auth.controller.js)
// stay in agreement without hardcoding the value in more than one spot.
const REMEMBER_ME_JWT_EXPIRES_IN = '30d';
const DEFAULT_SESSION_JWT_EXPIRES_IN = '1d';
const REMEMBER_ME_SESSION_DAYS = 30;
const DEFAULT_SESSION_DAYS = 1;

// Exposed so auth.controller.js can size the `jwt` cookie's maxAge to
// match, without redefining the 30/1 day figures in a second place.
exports.REMEMBER_ME_SESSION_DAYS = REMEMBER_ME_SESSION_DAYS;
exports.DEFAULT_SESSION_DAYS = DEFAULT_SESSION_DAYS;

// Create and send token (with cookie)
// `expiresIn` lets callers (login) override the default JWT lifetime;
// every other flow (signup, password reset, etc.) keeps using the
// project's normal JWT_EXPIRES_IN by omitting it.
const createSendToken = (user, expiresIn) => {
  if (!user || !user._id) {
    throw new AppError('Invalid user for token generation', 500);
  }
  const token = signToken(user._id, expiresIn);
  user.password = undefined; // Remove password from output
  return token;
};

// ==============================
// 🔸 Auth Service Functions
// ==============================

exports.signUp = async (data, url) => {
  const allowedData = {
    name: data.name,
    email: data.email,
    password: data.password,
    passwordConfirm: data.passwordConfirm,
  };

  if (data.photo) allowedData.photo = data.photo;
  if (data.bio) allowedData.bio = data.bio;
  if (data.website) allowedData.website = data.website;
  if (data.socialMedia) allowedData.socialMedia = data.socialMedia;

  const existingUser = await User.findOne({ email: allowedData.email });
  if (existingUser) {
    throw new AppError(
      'Email already registered. Please use another one.',
      409,
    );
  }

  // Create user with ONLY allowed fields
  const newUser = await User.create(allowedData);

  // Welcome email: started but not awaited, so a slow or failing mail
  // provider can neither delay nor fail signup. A failure is only logged.
  runInBackground('Welcome email', { userId: newUser.id }, () =>
    new Email(newUser, url).sendWelcome(),
  );

  recordActivity({ userId: newUser._id, action: 'signed_up' });

  const token = createSendToken(newUser);
  return { token, user: newUser };
};

exports.login = async (email, password, rememberMe = false) => {
  // Check if email and password exist
  if (!email || !password) {
    throw new AppError('Please provide email and password.', 400);
  }

  // (note) we added .select(+[field]) to select a field the select of it is false
  const user = await User.findOne({ email }).select('+password +active');

  // Check if user exists && password is correct
  if (!user || !(await user.correctPassword(password, user.password))) {
    throw new AppError('Incorrect email or password', 401);
  }
  if (!user.active) {
    throw new AppError(
      'Your account has been deactivated. Contact support.',
      401,
    );
  }

  // Update last login time
  user.lastLogin = new Date();
  await user.save({ validateBeforeSave: false });

  recordActivity({ userId: user._id, action: 'login' });

  // rememberMe=true -> long-lived (~30d) session; otherwise (false or
  // omitted) -> the short (~1d) session. This intentionally does not use
  // process.env.JWT_EXPIRES_IN, which remains the default lifetime for
  // signup/password-reset/etc. flows untouched by this option.
  const tokenExpiresIn = rememberMe
    ? REMEMBER_ME_JWT_EXPIRES_IN
    : DEFAULT_SESSION_JWT_EXPIRES_IN;

  // If everything ok, send token to client
  const token = createSendToken(user, tokenExpiresIn);
  return { token, user, rememberMe: !!rememberMe };
};

exports.forgotPassword = async (email) => {
  // T24: the delay must apply to BOTH branches, or its timing becomes the
  // enumeration signal it was meant to prevent (previously only the
  // not-found path waited ~1s, while the found path returned in the time
  // its DB write + email send took — often much less than 1s. Running the
  // delay in parallel with the real work via Promise.all means both
  // branches take at least ~1s, closing the gap without adding to it.
  const minDelay = new Promise((resolve) => {
    setTimeout(resolve, 1000);
  });

  // 1) Get user based on POSTed email
  const user = await User.findOne({ email }).select('+active');
  if (!user || !user.active) {
    await minDelay; // Do not reveal if user exists or not for security reasons
    return;
  }

  // 2) Generate the random token
  const resetToken = user.createPasswordResetToken();
  await user.save({ validateBeforeSave: false });

  recordActivity({ userId: user._id, action: 'requested_password_reset' });

  const resetURL = `${process.env.FRONTEND_URL}/reset-password/${resetToken}`;

  // 3) Send it to user's email
  try {
    await Promise.all([
      new Email(user, resetURL).sendPasswordReset(),
      minDelay,
    ]);
  } catch (err) {
    // If sending fails, reset token data and save again
    user.passwordResetToken = undefined;
    user.passwordResetExpires = undefined;
    await user.save({ validateBeforeSave: false });
    throw new AppError('Error sending the email. Try again later!', 500);
  }
};

exports.resetPassword = async (token, password, passwordConfirm) => {
  // 1) Get user based on the token
  const hashedToken = crypto.createHash('sha256').update(token).digest('hex');

  const user = await User.findOne({
    passwordResetToken: hashedToken,
    passwordResetExpires: { $gte: Date.now() },
  }).select('+active');

  // 2) If token has not expired, and there is user, set the new password

  if (!user) throw new AppError('Token is invalid or has expired', 400);

  if (!user.active) throw new AppError('Account deactivated', 401);

  user.password = password;
  user.passwordConfirm = passwordConfirm;
  user.passwordResetToken = undefined;
  user.passwordResetExpires = undefined;
  await user.save();

  recordActivity({ userId: user._id, action: 'reset_password' });

  // 3) Log user in, send JWT
  const jwtToken = createSendToken(user);
  return { token: jwtToken, user }; // Changed from jwtToken to token for consistency
};

exports.updatePassword = async (
  userId,
  passwordCurrent,
  password,
  passwordConfirm,
) => {
  // simple validation
  if (!passwordCurrent || !password || !passwordConfirm) {
    throw new AppError('All password fields are required', 400);
  }

  // 1) Get user from collection
  const user = await User.findById(userId).select('+password +active');

  if (!user) throw new AppError('User not found', 404);

  if (!user.active) throw new AppError('Account deactivated', 401);

  // 2) Check if POSTed current password is correct
  if (!(await user.correctPassword(passwordCurrent, user.password))) {
    throw new AppError('Your current password is wrong', 401);
  }

  // 3) If so, update password
  user.password = password;
  user.passwordConfirm = passwordConfirm;
  await user.save();

  recordActivity({ userId: user._id, action: 'updated_password' });

  // 4) Log user in, send JWT
  const token = createSendToken(user);
  return { token, user };
};

exports.logoutUser = (res) => {
  // Overwrite cookie with an expired dummy token
  res.cookie('jwt', 'loggedout', {
    expires: new Date(Date.now() + 10 * 1000), // expires in 10s
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: process.env.NODE_ENV === 'production' ? 'none' : 'lax',
  });
};
