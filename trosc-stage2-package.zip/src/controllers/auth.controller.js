const catchAsync = require('../utils/catchAsync');
const authService = require('../services/auth.service');
const { recordActivity } = require('../services/activityLog.service');

const { REMEMBER_ME_SESSION_DAYS, DEFAULT_SESSION_DAYS } = authService;

const setAuthCookie = (res, token, days) => {
  // Default to the project's normal cookie lifetime (JWT_COOKIE_EXPIRES_IN)
  // for every flow except login's "remember me" option, which passes an
  // explicit day count matching the token it just issued.
  const resolvedDays =
    days ?? (parseInt(process.env.JWT_COOKIE_EXPIRES_IN, 10) || 7); // Default to 7 days if not set

  const cookieOptions = {
    expires: new Date(Date.now() + resolvedDays * 24 * 60 * 60 * 1000),
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    // 'none' in production lets a cross-site frontend send the cookie. It
    // does NOT protect against CSRF (that is the weakest setting); 'lax'
    // is used in development where the frontend is same-site.
    sameSite: process.env.NODE_ENV === 'production' ? 'none' : 'lax',
  };

  res.cookie('jwt', token, cookieOptions);
};

exports.signup = catchAsync(async (req, res, next) => {
  const url = `${process.env.FRONTEND_URL}/dashboard`; // Adjust this URL as needed
  const { token, user } = await authService.signUp(req.body, url);

  setAuthCookie(res, token);

  res.status(201).json({
    status: 'success',
    token,
    data: { user },
  });
});

exports.login = catchAsync(async (req, res, next) => {
  const { email, password } = req.body;
  const rememberMe = req.body.rememberMe === true;
  const { token, user } = await authService.login(email, password, rememberMe);

  setAuthCookie(
    res,
    token,
    rememberMe ? REMEMBER_ME_SESSION_DAYS : DEFAULT_SESSION_DAYS,
  );

  res.status(200).json({
    status: 'success',
    token,
    data: { user },
  });
});

exports.logout = catchAsync(async (req, res, next) => {
  authService.logoutUser(res);

  if (req.user) {
    recordActivity({ userId: req.user.id, action: 'logout' });
  }

  res.status(200).json({
    status: 'success',
    message: 'Logged out successfully!',
  });
});

exports.forgotPassword = catchAsync(async (req, res, next) => {
  await authService.forgotPassword(req.body.email);

  res.status(200).json({
    status: 'success',
    message:
      'If an account exists, a reset link has been sent. Please check your email.',
  });
});

exports.resetPassword = catchAsync(async (req, res, next) => {
  const { password, passwordConfirm } = req.body;
  const { token, user } = await authService.resetPassword(
    req.params.token,
    password,
    passwordConfirm,
  );

  setAuthCookie(res, token);

  res.status(200).json({
    status: 'success',
    token,
    data: { user },
  });
});

exports.updatePassword = catchAsync(async (req, res, next) => {
  const { passwordCurrent, password, passwordConfirm } = req.body;
  const { token, user } = await authService.updatePassword(
    req.user.id,
    passwordCurrent,
    password,
    passwordConfirm,
  );

  setAuthCookie(res, token);

  res.status(200).json({
    status: 'success',
    token,
    data: { user },
  });
});
