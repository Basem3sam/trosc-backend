# 🎓 Trosc Backend

<p align="center">
  <img src="https://img.shields.io/badge/Node.js-18+-339933?logo=node.js&logoColor=white" alt="Node.js">
  <img src="https://img.shields.io/badge/Express.js-4.x-000000?logo=express&logoColor=white" alt="Express">
  <img src="https://img.shields.io/badge/MongoDB-Atlas-green?logo=mongodb&logoColor=white" alt="MongoDB">
  <img src="https://img.shields.io/badge/Swagger-3.0-orange?logo=swagger&logoColor=white" alt="Swagger">
  <img src="https://img.shields.io/badge/JWT-Auth-000000?logo=jsonwebtokens&logoColor=white" alt="JWT">
  <img src="https://img.shields.io/badge/Tests-Jest%20%2B%20Supertest-C21325?logo=jest&logoColor=white" alt="Tests">
  <img src="https://img.shields.io/badge/License-ISC-blue.svg" alt="License">
</p>
<p align="center">
  <img src="https://github.com/basem3sam/trosc-backend/actions/workflows/test.yml/badge.svg" alt="Test Status">
</p>

<p align="center">
  <b>Backend API for Trosc</b> — the student club at <em>Faculty of Computers and Informatics, Suez Canal University</em>.<br>
  Built to be <strong>cheap, fast, and maintainable</strong>. Media lives on YouTube & Google Drive, not your server.
</p>

---

## 📋 Table of Contents

- [Features](#-features)
- [Tech Stack](#-tech-stack)
- [Architecture](#-architecture)
- [System Design](#-system-design)
- [Database Overview](#-database-overview)
- [Quick Start](#-quick-start)
- [Environment Variables](#-environment-variables)
- [API Documentation](#-api-documentation)
- [Authentication Flow](#-authentication-flow)
- [Key Architectural Decisions](#-key-architectural-decisions)
- [Security](#-security)
- [Cost Strategy](#-cost-strategy)
- [Scripts & Utilities](#-scripts--utilities)
- [Deployment Guide](#-deployment-guide)
- [Testing](#-testing)
- [Roadmap](#-roadmap)
- [Troubleshooting](#-troubleshooting)
- [Contributing](#-contributing)
- [License](#-license)

---

## ✨ Features

| Feature                   | Description                                                                                                                                                                                                        |
| ------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 🔐 **Authentication**     | JWT (bearer + httpOnly cookie), role-based access control (`student` / `instructor` / `admin`), optional `rememberMe` on login for a long-lived (~30 day) vs. default (~1 day) session                            |
| 📚 **Learning Tracks**    | Structured curricula grouping courses and sessions; instructor can be reassigned by an admin; public session catalog (`GET /tracks/:id/session-catalog`) for pre-enrollment browsing              |
| 🎬 **Courses & Sessions** | YouTube / Google Drive integration — zero storage cost; per-student "watched" progress tracking on sessions (`PUT /sessions/:id/progress`, `myProgress` on `GET /sessions/:id`)                   |
| 📅 **Events**             | Online/offline events with RSVP and attendance tracking                                                                                                                                                            |
| 📌 **Announcements**      | Pinned posts with audience targeting (`all` / `track` / `course`)                                                                                                                                                  |
| 📊 **Dashboard Feed**     | Aggregated pinned announcements + upcoming events                                                                                                                                                                  |
| 🛡️ **Ownership Model**    | Instructors edit only their own content; admins bypass restrictions                                                                                                                                                |
| ⚡ **Bulk Actions**       | Admin tools for mass user activation, deactivation, or deletion                                                                                                                                                    |
| 🔍 **Full-Text Search**   | MongoDB text indexes on tracks, courses, and sessions; regex-based name/email search plus active/inactive filtering on the admin user list                                                                        |
| 📈 **Track Analytics**    | Enrollment rates, student counts, and engagement metrics                                                                                                                                                           |
| ✉️ **Contact Form**       | Public contact submission, stored + emailed to admin; admins can list, view, and triage submissions (`new` / `read` / `archived`)                                                                                  |
| ⭐ **Reviews**            | Enrolled students rate & review tracks, courses, and sessions (1–5 stars, one per student per resource); review's own author or an admin can delete it                                                             |
| 📝 **Assignments**        | Full CRUD (owner instructor / admin) at the course and standalone-session level, plus track-aggregated listing; student submission/resubmission with a computed `late` flag; instructor/admin grading with optional written feedback; gated staff access to open a student's submitted file          |
| 📅 **Weekly Tasks**       | Per-course weekly task buckets with typed items (reading/quiz/video) and per-student completion tracking                                                                                                           |
| 🧾 **Activity Logs**      | Server-written audit trail (signup, login, enrollment, profile changes, admin bulk actions, …); self-service "my activity" timeline plus admin listing, per-user lookup, aggregated summary, and retention pruning |
| 📈 **Dashboard Stats**    | Admin-only analytics: live platform stats computed on demand, plus persisted daily/weekly/monthly snapshots for trend charts (upsertable, cron-friendly, retention pruning)                                        |

---

## 🧰 Tech Stack

| Layer          | Technology                                      | Version  |
| -------------- | ----------------------------------------------- | -------- |
| **Runtime**    | Node.js                                         | ≥ 20 LTS |
| **Framework**  | Express.js                                      | 4.x      |
| **Database**   | MongoDB (Mongoose ODM)                          | 8.x+     |
| **Auth**       | JWT (jsonwebtoken) + bcrypt                     | —        |
| **Validation** | Joi                                             | 18.x     |
| **Security**   | Helmet, express-rate-limit, mongo-sanitize, hpp | —        |
| **Email**      | Nodemailer + html-to-text                       | —        |
| **Docs**       | Swagger (swagger-jsdoc + swagger-ui-express)    | 3.0      |
| **Logging**    | Winston + DailyRotateFile                       | —        |
| **Testing**    | Jest + Supertest + mongodb-memory-server        | —        |
| **Tooling**    | ESLint (airbnb-base) + Prettier                 | —        |

> **Design Principle:** No file uploads. All media (images, videos, PDFs) are referenced via URLs from trusted hosts (YouTube, Google Drive, Cloudinary, Imgur, GitHub, Dropbox). This keeps hosting 100% free.

---

## 📁 Architecture

```
src/
├── app.js                 # Express app setup, global middleware, route mounting
├── server.js              # Entry point: env validation, DB connection, error handlers
│
├── controllers/           # Thin request/response handlers (delegate to services)
│   ├── auth.controller.js
│   ├── user.controller.js
│   ├── track.controller.js
│   ├── course.controller.js
│   ├── session.controller.js
│   ├── event.controller.js
│   ├── announcement.controller.js
│   ├── review.controller.js
│   ├── assignment.controller.js
│   ├── assignmentSubmission.controller.js
│   ├── weeklyTask.controller.js
│   ├── contact.controller.js
│   ├── feed.controller.js
│   ├── activityLog.controller.js
│   ├── dashboardStats.controller.js
│   └── error.controller.js      # Global error handler (dev vs prod responses, Mongo/JWT error mapping)
│
├── services/              # Business logic & database operations
│   ├── auth.service.js
│   ├── user.service.js
│   ├── track.service.js
│   ├── course.service.js
│   ├── session.service.js
│   ├── event.service.js
│   ├── announcement.service.js
│   ├── review.service.js
│   ├── assignment.service.js
│   ├── assignmentSubmission.service.js
│   ├── weeklyTask.service.js
│   ├── contact.service.js
│   ├── enrollment.service.js    # Enrollment rules & prerequisites
│   ├── cascade.service.js       # Keeps User enrollments in sync across collections (with MongoDB transactions)
│   ├── activityLog.service.js   # Audit-trail writes (internal only, no public POST) + reads/summary/prune
│   └── dashboardStats.service.js # Period-boundary math, live/snapshot stat computation, trends, prune
│
├── models/                # Mongoose schemas + Swagger component definitions
│   ├── user.model.js
│   ├── track.model.js
│   ├── course.model.js
│   ├── session.model.js
│   ├── event.model.js
│   ├── announcement.model.js
│   ├── review.model.js
│   ├── assignment.model.js
│   ├── weeklytask.model.js
│   ├── contact.model.js
│   ├── activitylog.model.js     # Audit-log entries; user+createdAt/action+createdAt/targetModel+targetId indexes
│   └── dashboardstats.model.js  # Point-in-time stat snapshots; unique (period, date) compound index
│
├── routes/                # Route definitions + Swagger JSDoc annotations
│   ├── user.route.js
│   ├── track.route.js
│   ├── course.route.js
│   ├── session.route.js
│   ├── event.route.js
│   ├── announcement.route.js
│   ├── review.route.js              # generic factory, mounted per resource type
│   ├── resourceAssignment.route.js  # generic factory, mounted per resource type
│   ├── assignment.route.js          # track-level aggregated assignment listing
│   ├── assignmentSubmission.route.js
│   ├── weeklyTask.route.js
│   ├── weeklyTaskProgress.route.js  # top-level /v1/weekly-tasks mount (per-item completion toggling)
│   ├── trackWeeklyTask.route.js     # track-level aggregated weekly-task listing
│   ├── contact.route.js
│   ├── feed.route.js
│   ├── activityLog.route.js
│   └── dashboardStats.route.js
│
├── validations/           # Joi schemas for request body/params/query
│   ├── user.validation.js
│   ├── track.validation.js
│   ├── course.validation.js
│   ├── session.validation.js
│   ├── event.validation.js
│   ├── announcement.validation.js
│   ├── review.validation.js
│   ├── assignment.validation.js
│   ├── assignmentSubmission.validation.js
│   ├── weeklyTask.validation.js
│   ├── contact.validation.js
│   ├── activityLog.validation.js
│   └── dashboardStats.validation.js
│
├── middlewares/           # Reusable Express middleware
│   ├── auth.middleware.js       # protect, restrictTo, checkOwnership
│   ├── ownership.middleware.js
│   ├── rateLimit.middleware.js  # authLimiter — applied to login/signup/reset + enrollment/RSVP/contact endpoints
│   ├── validate.middleware.js
│   └── selfApproval.js
│
├── utils/                 # Reusable utilities
│   ├── APIFeatures.js         # Filter, sort, paginate, search
│   ├── AppError.js            # Operational error class
│   ├── catchAsync.js          # Async handler wrapper
│   ├── Email.js               # HTML email templates with plaintext fallback
│   ├── escapeHtml.js          # Escapes user input before interpolating into HTML email bodies
│   ├── generateToken.js
│   ├── logger.js              # Winston configuration with log rotation
│   ├── trustedHosts.js        # single source of truth for the attachment/resource host allowlist (the data)
│   ├── isTrustedHost.js       # single source of truth for matching a URL's host against that allowlist (the logic)
│   ├── validateAttachments.js
│   ├── attachmentValidation.js
│   └── photoValidation.js
│
└── config/                # Configuration & bootstrapping
    ├── db.config.js
    ├── env.config.js
    ├── mailer.config.js
    └── swagger.config.js

scripts/                   # One-off / cron-triggered CLI utilities (outside src/)
├── createAdmin.js
└── generateDashboardSnapshot.js
```

### Design Patterns Used

- **Service Layer**: Controllers are thin; all business logic lives in services.
- **Cascade Service**: Centralized synchronization of `User.enrolledTracks`, `enrolledCourses`, and `enrolledSessions` to prevent data drift — now with **MongoDB transactions** for atomicity.
- **Ownership Middleware**: Generic, reusable authorization factory that checks `instructor`, `createdBy`, or `user` fields before allowing mutations — used consistently across tracks, courses, sessions, announcements, events, weekly tasks, assignments, and reviews.
- **Resource-Type Factories**: `review.route.js` and `resourceAssignment.route.js` each export a single factory function mounted three times (`track` / `course` / `session`), so create/list/delete logic for reviews and assignments is written once and shared, not duplicated per resource type.
- **Factory Functions**: `catchAsync`, `checkOwnership`, and `APIFeatures` reduce boilerplate.
- **Internal-Only Write Path for Audit Data**: `activityLog.service.js`'s `logActivity()` is called from other services as a side effect (signup, login, enrollment, profile updates, admin bulk actions) — there is deliberately no public `POST /v1/activity-logs` endpoint, so a client can never forge its own audit history. It also never throws: a failed audit write is logged and swallowed rather than failing the request that triggered it.
- **Snapshot-Based Analytics**: `dashboardStats.service.js` separates "compute" from "persist" — the same `computeStats()` aggregation powers both the live, never-saved `GET /dashboard-stats/live` endpoint and the persisted, upsertable `generateSnapshot()` used for daily/weekly/monthly trend data.

---

## 🏗️ System Design

<details>
<summary>📐 Data Flow Diagram (Level 1) (click to expand)</summary>
<br>

```mermaid
flowchart TD
    subgraph ext [External Entities]
        direction LR
        Student([Student / User])
        Instructor([Instructor])
        Admin([Admin])
    end

    subgraph auth [Authentication]
        P1[1.0 Authenticate User]
    end

    subgraph content [Content Management]
        direction TB
        P2[2.0 Manage Tracks, Courses, Sessions]
        P3[3.0 Manage Events]
        P4[4.0 Manage Announcements]
    end

    subgraph enroll [Enrollment & Approval]
        P5[5.0 Process Enrollment & RSVP]
    end

    subgraph feed [Dashboard & Discovery]
        P6[6.0 Build Dashboard Feed]
    end

    subgraph stores [Data Stores]
        direction TB
        DS1[(User Store)]
        DS2[(Content Store<br/>Tracks, Courses, Sessions)]
        DS3[(Event Store)]
        DS4[(Announcement Store)]
    end

    %% Authentication flows
    Student -->|signup / login credentials| P1
    Instructor -->|login credentials| P1
    Admin -->|login credentials| P1
    P1 -->|JWT token + user profile| Student
    P1 -->|JWT token + user profile| Instructor
    P1 -->|JWT token + user profile| Admin
    P1 <-->|read / write user record, lastLogin| DS1

    %% Content CRUD (Instructor + Admin)
    Instructor -->|create / update / delete content| P2
    Admin -->|create / update / delete / bulk| P2
    P2 <-->|read / write tracks, courses, sessions| DS2
    P2 <-->|read / write instructor ref| DS1

    Instructor -->|create / update event| P3
    Admin -->|create / update event| P3
    Student -->|RSVP / cancel RSVP| P3
    P3 <-->|read / write events| DS3
    P3 <-->|read creator ref| DS1

    Instructor -->|create / update announcement| P4
    Admin -->|create / update announcement| P4
    P4 <-->|read / write announcements| DS4
    P4 <-->|read creator ref| DS1

    %% Enrollment & Approval
    Student -->|self-enroll / request leave| P5
    Instructor -->|manual add / approve / reject| P5
    Admin -->|manual add / bulk manage| P5
    P5 -->|update enrolledTracks / Courses / Sessions| DS1
    P5 -->|update students / pending / pendingLeaves| DS2

    %% Public browsing & Feed
    Student -->|browse / view / search| P2
    P2 -->|public content + instructor info| Student
    Student -->|request dashboard| P6
    P6 -->|pinned + upcoming + creator info| Student
    DS1 -->|user / creator data| P6
    DS3 -->|upcoming events| P6
    DS4 -->|pinned announcements| P6
```

</details>

<details>
<summary>📊 Entity Relationship Diagram (click to expand)</summary>
<br>

> Rendered from [`design/trosc-ERD.mmd`](./design/trosc-ERD.mmd) — open that file directly (or paste it into [mermaid.live](https://mermaid.live)) for the full entity/field breakdown; it's long enough that inlining it here would hurt readability.

</details>

> 📂 Source files: [`design/trosc-DFD-level1.mmd`](./design/trosc-DFD-level1.mmd) · [`design/trosc-ERD.mmd`](./design/trosc-ERD.mmd)
>
> ⚠️ **Note:** both diagrams predate the reviews, assignments, weekly-tasks, and contact-form features and only model the original auth/content/events/announcements/feed slice of the API. They're useful for the high-level shape of the system but shouldn't be treated as exhaustive — see the [Database Overview](#-database-overview) table below for the current, complete collection list.

---

## 🗄️ Database Overview

| Collection       | Purpose                               | Key Indexes                                                                              |
| ---------------- | ------------------------------------- | ---------------------------------------------------------------------------------------- |
| `users`          | Authentication, profiles, enrollments | `email` (unique), `enrolledTrack`                                                        |
| `tracks`         | Learning paths                        | `title` (text), `instructor`, `students`, `pendingStudents`, `published+level`           |
| `courses`        | Course content                        | `title` (text), `track`, `instructor`, `students`, `published+level`                     |
| `sessions`       | Video sessions                        | `tracks`, `course`, `instructor`, `published+level`                                      |
| `events`         | Club events & RSVP                    | `date` (for upcoming feed)                                                               |
| `announcements`  | Pinned posts                          | `isPinned` + `createdAt` (compound)                                                      |
| `reviews`        | Ratings & feedback                    | one partial-unique index per resource type (`track+user`, `course+user`, `session+user`) |
| `assignments`    | Course/session assignments            | `course`, `session`, `instructor`                                                        |
| `weeklytasks`    | Per-course weekly task buckets        | `course + week` (unique), `instructor`                                                   |
| `contacts`       | Contact form submissions              | none beyond `_id` — low volume, admin-triaged                                            |
| `activitylogs`   | Audit trail of user actions           | `user + createdAt`, `action + createdAt`, `targetModel + targetId`, `createdAt`          |
| `dashboardstats` | Point-in-time analytics snapshots     | `period + date` (unique — enables upsert-in-place regeneration)                          |

### Enrollment Cascade Rules

When a student joins a **track**, the system automatically enrolls them in:

- All courses within that track
- All sessions within that track
- Updates `User.enrolledTrack`, `User.enrolledCourses`, `User.enrolledSessions`

When a student **leaves** (or is removed), all of the above are reversed atomically.

While a self-enroll request (`POST /tracks/:id/enroll-me`) is awaiting instructor/admin approval, the student is only in that track's `pendingStudents` array — `User.enrolledTrack` stays `null` until approved. `GET /v1/users/me` surfaces this as a computed `pendingTrack` field (the track's `_id`, or `null` if there's no pending request), read live from `Track.pendingStudents` rather than duplicated onto the `User` document.

Deleting a **course** or **track** also cascades to remove its assignments, reviews, and weekly tasks, so nothing is left pointing at a deleted parent.

Removing a **course** or **session** from a track (without deleting the track itself) unenrolls that track's current students from it, mirroring the auto-enroll that happens when a course/session is added to a track. This is a known-good approximation rather than a fully general rule: it can't yet distinguish a student who has access _only_ because of the track from one who separately, directly enrolled in that same course/session — both are unenrolled on detach, since enrollment records don't currently track _how_ a student got access. A student who joins the track again, or re-enrolls directly, gets access back the normal way.

> **Known limitation:** `User.enrolledCourses`/`enrolledSessions` are flat arrays with no record of enrollment provenance (track vs. direct). A student who is both a track member and separately enrolled in one of that track's courses will lose access to it if the course is ever detached from the track — even though they'd have kept independent access under a fully correct implementation. Fixing this properly needs a provenance field (or a separate `Enrollment` collection) plus a data migration; tracked as a larger follow-up, not blocking day-to-day use.

> ✅ **Note:** MongoDB transactions are fully implemented in `cascade.service.js` for all critical enrollment sync operations, ensuring consistency even under race conditions.

---

## ⚡ Quick Start

### Prerequisites

- [Node.js](https://nodejs.org/) ≥ 20
- [MongoDB](https://www.mongodb.com/) (local or [Atlas free tier](https://www.mongodb.com/atlas))
- (Optional) [Mailtrap](https://mailtrap.io/) account for email testing

### 1. Clone & Install

```bash
git clone https://github.com/basem3sam/trosc-backend.git
cd trosc-backend
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your credentials
```

See the [Environment Variables](#-environment-variables) section for the full reference.

### 3. Run

```bash
# Development (nodemon + debug logging)
npm start

# Production
NODE_ENV=production npm start
```

The server will start on `http://localhost:5000` (or your `PORT`).

### 4. Verify

```bash
# Health check
curl http://localhost:5000/health

# Swagger UI
open http://localhost:5000/api-docs
```

---

## 🔧 Environment Variables

| Variable                    | Required | Default                           | Description                                                                              |
| --------------------------- | -------- | --------------------------------- | ---------------------------------------------------------------------------------------- |
| `NODE_ENV`                  | ✅       | `development`                     | `development` or `production`                                                            |
| `PORT`                      | ❌       | `5000`                            | Server port                                                                              |
| `DATABASE_URL`              | ✅       | —                                 | MongoDB connection string                                                                |
| `DATABASE_PASSWORD`         | ❌       | —                                 | If using `<PASSWORD>` placeholder in URL                                                 |
| `DATABASE_USERNAME`         | ❌       | —                                 | If using `<USERNAME>` placeholder in URL                                                 |
| `JWT_SECRET`                | ✅       | —                                 | Min 32 characters                                                                        |
| `JWT_EXPIRES_IN`            | ✅       | `7d`                              | Token lifetime for signup / password-reset / password-update (e.g., `90d`, `30d`). **Not** used by `/login`, which sizes its own token from `rememberMe` instead — see [Authentication Flow](#-authentication-flow) |
| `JWT_COOKIE_EXPIRES_IN`     | ❌       | `7`                               | Cookie expiry in days for every auth response except `/login` (same `rememberMe` carve-out as above)                                    |
| `FRONTEND_URL`              | ✅       | —                                 | For CORS and password reset links                                                        |
| `EXTRA_CORS_ORIGINS`        | ❌       | —                                 | Comma-separated extra allowed origins, added on top of `FRONTEND_URL` (see `src/app.js`) |
| `BASE_URL`                  | ❌       | `http://localhost:5000`           | Server base URL                                                                          |
| `RATE_LIMIT_MAX`            | ❌       | `300`                             | Max requests per window per IP                                                           |
| `RATE_LIMIT_WINDOW_MS`      | ❌       | `900000`                          | Rate limit window (15 min in ms)                                                         |
| `AUTH_RATE_LIMIT_MAX`       | ❌       | `5`                               | Max auth attempts per window                                                             |
| `AUTH_RATE_LIMIT_WINDOW_MS` | ❌       | `900000`                          | Auth rate limit window                                                                   |
| `MONGODB_POOL_SIZE`         | ❌       | `10`                              | Connection pool size                                                                     |
| `EMAIL_HOST`                | ✅\*     | —                                 | SMTP host (dev: Mailtrap)                                                                |
| `EMAIL_PORT`                | ✅\*     | `2525`                            | SMTP port                                                                                |
| `EMAIL_USER`                | ✅\*     | —                                 | SMTP username                                                                            |
| `EMAIL_PASS`                | ✅\*     | —                                 | SMTP password                                                                            |
| `EMAIL_FROM`                | ❌       | `Trosc Club <noreply@trosc.club>` | Sender address                                                                           |
| `EMAIL_SERVICE`             | ❌       | `Gmail`                           | Used in production instead of host/port                                                  |
| `ADMIN_EMAIL`               | ❌       | —                                 | Inbox notified on new contact form submissions                                           |
| `TEST_EMAIL`                | ❌       | —                                 | Recipient used by `testEmail.js` when no address is passed on the command line           |

\* Required if sending emails (password reset, welcome). Not required for basic API operation.

### Example `.env`

```env
NODE_ENV=development
PORT=5000

DATABASE_URL=mongodb+srv://user:pass@cluster.mongodb.net/trosc
# Or local: mongodb://localhost:27017/trosc

JWT_SECRET=your_super_secret_key_min_32_chars_here
JWT_EXPIRES_IN=7d
JWT_COOKIE_EXPIRES_IN=7

FRONTEND_URL=http://localhost:3000
BASE_URL=http://localhost:5000

RATE_LIMIT_MAX=300
RATE_LIMIT_WINDOW_MS=900000
MONGODB_POOL_SIZE=10

EMAIL_HOST=smtp.mailtrap.io
EMAIL_PORT=2525
EMAIL_USER=your_mailtrap_user
EMAIL_PASS=your_mailtrap_pass
EMAIL_FROM=Trosc Club <noreply@trosc.club>

ADMIN_EMAIL=admin@trosc.club
```

---

## 📚 API Documentation

### Quick Reference

| Resource            | Base Endpoint                                               | Key Capabilities                                  |
| ------------------- | ----------------------------------------------------------- | ------------------------------------------------- |
| **Auth**            | `/v1/users`                                                 | signup, login, logout, password reset             |
| **Users**           | `/v1/users`                                                 | profiles, enrollments, bulk actions               |
| **Tracks**          | `/v1/tracks`                                                | CRUD, enrollment approval, analytics              |
| **Courses**         | `/v1/courses`                                               | CRUD, session management, prerequisites           |
| **Sessions**        | `/v1/sessions`                                              | CRUD, student gating, YouTube/Drive URLs          |
| **Events**          | `/v1/events`                                                | CRUD, RSVP, online/offline locations              |
| **Announcements**   | `/v1/announcements`                                         | Pinned posts, audience targeting                  |
| **Reviews**         | `/v1/{tracks,courses,sessions}/:id/reviews`                 | Create, list, delete (author/admin)               |
| **Assignments**     | `/v1/{courses,sessions}/:id/assignments`, `/v1/assignments` | CRUD, submissions, grading                        |
| **Weekly Tasks**    | `/v1/courses/:id/weekly-tasks`, `/v1/weekly-tasks`          | CRUD, per-item completion tracking                |
| **Feed**            | `/v1/feed`                                                  | Dashboard aggregation                             |
| **Contact**         | `/v1/contact`                                               | Public submission; admin list/view/triage         |
| **Activity Logs**   | `/v1/activity-logs`                                         | Self "my activity"; admin list/user/summary/prune |
| **Dashboard Stats** | `/v1/dashboard-stats`                                       | Admin-only: live stats, snapshots, trends, prune  |
| **Health**          | `/health`                                                   | Server & DB status                                |

📖 **Full endpoint table →** [`API.md`](./API.md)

### Interactive Docs

Run the server and open:

```
http://localhost:5000/api-docs
```

The Swagger UI includes request schemas, response formats, authentication helpers, and live "Try it out" functionality.

### Authentication

The API uses **dual-token delivery**:

1. **Authorization Header** for API clients: `Authorization: Bearer <jwt>`
2. **httpOnly Cookie** for browser clients: `jwt=<token>`

Protected endpoints require at least one of the above.

### Example Request Flow

```bash
# 1. Sign up
curl -X POST http://localhost:5000/v1/users/signup \
  -H "Content-Type: application/json" \
  -d '{"name":"Basem","email":"basem@example.com","password":"StrongPass123","passwordConfirm":"StrongPass123"}'

# 2. Log in (stores cookie + returns token)
curl -X POST http://localhost:5000/v1/users/login \
  -H "Content-Type: application/json" \
  -d '{"email":"basem@example.com","password":"StrongPass123"}'

# 3. Access protected route
curl http://localhost:5000/v1/users/me \
  -H "Authorization: Bearer <token_from_login>"
```

### Response Envelope

All successful list responses follow this structure:

```json
{
  "status": "success",
  "results": 10,
  "total": 45,
  "pagination": {
    "page": 1,
    "limit": 10,
    "totalPages": 5,
    "totalResults": 45,
    "hasNext": true,
    "hasPrev": false
  },
  "data": { ... }
}
```

### Error Response Structure

```json
{
  "status": "fail",
  "message": "Invalid input: title is required"
}
```

Common HTTP status codes:

- `200` – Success
- `201` – Created
- `204` – No Content (successful deletion)
- `400` – Bad Request (validation error)
- `401` – Unauthorized (missing or invalid token)
- `403` – Forbidden (insufficient permissions)
- `404` – Not Found
- `409` – Conflict (duplicate resource, or a blocked action such as deleting a user who still owns required content)
- `429` – Too Many Requests (rate limited)
- `500` – Internal Server Error

---

## 🔐 Authentication Flow

```
┌──────────┐       ┌──────────┐      ┌──────────┐       ┌──────────┐
│  Client  │─────▶│  Login   │─────▶│  Server  │─────▶│  MongoDB │
└──────────┘       └──────────┘      └──────────┘       └──────────┘
                                           │
                                           ▼
                                     ┌──────────┐
                                     │  bcrypt  │
                                     │  compare │
                                     └──────────┘
                                           │
                                           ▼
                                     ┌──────────┐
                                     │   JWT    │
                                     │  sign()  │
                                     └──────────┘
                                           │
                                           ▼
┌──────────┐       ┌──────────┐      ┌──────────┐
│  Client  │◀─────│  Cookie  │◀─────│  Server  │
│  (store) │       │  + JSON  │      │          │
└──────────┘       └──────────┘      └──────────┘
```

1. Client sends `email` + `password`, and optionally `rememberMe: true`.
2. Server hashes password with bcrypt (cost 12) and compares.
3. If valid, server signs a JWT with `user._id` and an expiry that depends on `rememberMe`: **~30 days** if `true`, **~1 day** if `false` or omitted.
4. Server sends the token in the JSON body **and** sets an `httpOnly` cookie (`secure` + `sameSite: 'none'` in production, `sameSite: 'lax'` in development) whose `maxAge` matches the same ~30/~1 day choice.
5. Subsequent requests send either the cookie automatically or the `Authorization: Bearer <token>` header.
6. Signup, password reset, and password update use the same cookie settings but always the default (`JWT_EXPIRES_IN`/`JWT_COOKIE_EXPIRES_IN`-controlled) lifetime — `rememberMe` is a `/login`-only option.

---

## 🏛️ Key Architectural Decisions

### 1. No File Uploads

Instead of S3/Cloudinary storage costs, all media is referenced by URL. The system validates URLs against a single, shared whitelist of trusted hosts (`src/utils/trustedHosts.js` — YouTube, Drive, Dropbox, GitHub, Cloudinary, Imgur, Discord CDN), used consistently by both the Mongoose-level and Joi-level attachment validators, and served as-is at `GET /v1/config/trusted-hosts` so a form can warn about an untrusted host before submitting. Cloudinary is documented here as a possible **future, optional** enhancement (authenticated/private delivery + backend-generated signed URLs, never a permanent public URL, and the API secret never reaches the frontend) — it is not implemented and nothing in the current stages requires it. Google Drive/other trusted-host links remain the free, always-available fallback. **Assignment submissions follow the same design: a submission is a link (`POST /assignments/:id/submissions` with JSON `{ "file": "<https link>" }`), not a file upload — multipart is rejected with a message saying so, and the error for an untrusted host lists every allowed host.**

### 2. Cascade Enrollment Service with Transactions

Instead of scattering enrollment logic across controllers, a dedicated `cascade.service.js` handles the many-to-many synchronization between `User` and `Track`/`Course`/`Session`. This prevents bugs where a user is in a track but not its courses. Deleting a course or track similarly cascades to clean up its assignments, reviews, and weekly tasks rather than leaving them orphaned. The same guarantee holds for a narrower operation: detaching a course or session from a track (without deleting the track) unenrolls that track's current students from it too, so nobody stays enrolled in content that's no longer reachable through the track that gated it.

**All critical cascade operations use MongoDB transactions** for atomicity, ensuring the system never ends up in an inconsistent state.

### 3. Generic Ownership Middleware (and the stage-4 policy layer)

`checkOwnership` (model name + owner field + param name) still guards the
creator-based resources: announcements, events and review deletion.

For tracks, courses, sessions, assignments and weekly tasks, authorization
moved in stage 4 to **`src/services/policy.service.js`**, enforced through the
`requireManage` and `requireTrackLink` middlewares
(`src/middlewares/managePolicy.middleware.js`). The rule is computed from the
caller's *current* role and staff membership (admin; or an instructor who is
the item's / its course's instructor, or lead or co-instructor of its track) —
never from who created something. Resources are resolved with a few
projection-only queries and cached on `req.policyCache`; list endpoints
resolve parents in batches. See API.md → "Authorization model".

### 4. Resource-Type Factories for Reviews & Assignments

Reviews and assignments both attach to three different parent types (track, course, session) with identical business rules (enrollment required to create, one review per student, owner-or-admin required to mutate). Rather than triplicating that logic, `review.route.js` and `resourceAssignment.route.js` each export a single factory function parameterized by resource type, mounted once per parent router.

### 5. Joi + Swagger Co-location

Validation schemas (Joi) are defined in `validations/` and referenced in route JSDoc. This ensures the API docs never drift from the actual validation rules.

### 6. `rememberMe` as a Login-Only Override

Rather than changing the global `JWT_EXPIRES_IN`/`JWT_COOKIE_EXPIRES_IN` env vars (which would also affect signup, password reset, and password update), `POST /login` computes its own token/cookie lifetime from the request's `rememberMe` boolean (~30 days if `true`, ~1 day otherwise) and passes it explicitly to `generateToken`/`setAuthCookie`. Every other cookie security setting (`httpOnly`, `secure`, `sameSite`) is untouched, and every other auth flow keeps using the env-configured default.

### 7. `pendingTrack` Is Computed, Not Stored

`GET /users/me` reports `pendingTrack` (the track a student has applied to but isn't approved into yet) by querying `Track.pendingStudents` for the caller's ID at request time — the same field `enrollMeInTrack`/`approveStudentInTrack`/`rejectStudentInTrack` already read and write in `enrollment.service.js`. No second, duplicate "pending" field was added to the `User` model.

### 8. Centralized Read/Visibility Policy (`policy.service.js`)

Draft (`published: false`) visibility rules — "an admin or the resource's current owner can see it, nobody else, and it doesn't even appear in a list for anyone else" — used to be re-derived inline in each service, which is how `session.service.js`'s list endpoints (`getSessionsByTrack` in particular) ended up with no draft filtering and no content redaction at all, even though `getSessionById` had a version of it and `track`/`course` detail endpoints had another. `src/services/policy.service.js` is now the one place that logic lives (`isAdmin`, `isOwnerOf`, `canViewDraft`, `canViewResource`, `publishedListFilter`), used by every session/track/course read path. It is scoped to **read/visibility only** for now; management-permission checks (create/edit/delete/grade) still go through `checkOwnership`. A later stage extends this same layer to cover current-role/current-staff-membership-based management authorization (never historical `createdBy`) once co-instructor support lands.

---

## 🛡️ Security

| Layer                   | Implementation                                                                                                                                                                                                              |
| ----------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **HTTP Headers**        | Helmet (CSP, HSTS, X-Frame-Options, etc.)                                                                                                                                                                                   |
| **Rate Limiting**       | 300 req / 15 min (global); 5 req / 15 min (auth endpoints)                                                                                                                                                                  |
| **NoSQL Injection**     | `express-mongo-sanitize` strips `$` and `.` from user input                                                                                                                                                                 |
| **Parameter Pollution** | `hpp` whitelists array fields (`role`, `level`, `prerequisites`, etc.)                                                                                                                                                      |
| **CORS**                | Whitelist-based with credentials; ngrok allowed in dev                                                                                                                                                                      |
| **Passwords**           | bcrypt (cost 12), never returned in queries (`select: false`)                                                                                                                                                               |
| **JWT**                 | `httpOnly` cookie (`secure` + `sameSite: 'none'` in production, `sameSite: 'lax'` in development); login's expiry depends on `rememberMe` (~1 day default, ~30 days if true) — see [Authentication Flow](#-authentication-flow) |
| **Input Validation**    | Joi on all body/params/query; custom URL validators for attachments                                                                                                                                                         |
| **Ownership**           | Instructors can only mutate their own content; review authors can only delete their own review; admins bypass both                                                                                                          |
| **Body Spoofing**       | Controllers delete `req.body.instructor`, `req.body.students`, etc. before saving                                                                                                                                           |
| **Data Exposure**       | Enrolled-student lists (name/email/photo) on public track/course detail pages are only populated for the owner, an admin, or an enrolled caller — never shown to anonymous or unrelated visitors                            |
| **Draft Visibility**    | `published: false` tracks/courses/sessions are invisible (404, not content-redacted) to anyone but their current owner or an admin, on both single-item and list endpoints (`src/services/policy.service.js`)             |
| **Audit Trail**         | `activityLog.service.js` writes are internal-only (no public `POST` endpoint) — a client can never forge its own history; a failed audit write is logged and swallowed, never allowed to fail the request that triggered it |

---

## 💰 Cost Strategy

| Feature         | Solution                                | Cost      |
| --------------- | --------------------------------------- | --------- |
| Video hosting   | YouTube / Google Drive                  | Free      |
| Images          | External URLs (Cloudinary, Imgur, etc.) | Free      |
| Database        | MongoDB Atlas M0 (512 MB)               | Free      |
| Backend hosting | Render / Railway / Fly.io               | Free tier |
| Email           | Mailtrap (dev) / Gmail (prod)           | Free tier |
| File storage    | None — we don't store files             | $0        |

---

## 🛠️ Scripts & Utilities

| Command                                                                         | Description                                                              |
| ------------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
| `npm start`                                                                     | Development mode with nodemon                                            |
| `npm start:prod`                                                                | Production mode                                                          |
| `npm run swagger:export`                                                        | Generate `swagger.json` from JSDoc comments                              |
| `npm test`                                                                      | Run Jest test suite                                                      |
| `npm run test:watch`                                                            | Run tests in watch mode                                                  |
| `npm run test:coverage`                                                         | Run tests with coverage report                                           |
| `npm run lint`                                                                  | Run ESLint                                                               |
| `npm run lint:fix`                                                              | Fix ESLint issues automatically                                          |
| `npm run lint:check`                                                            | Run ESLint with `--max-warnings=0` (fails on any warning — what CI runs) |
| `node testEmail.js <email>`                                                     | Diagnose SMTP configuration and send a test email                        |
| `node scripts/createAdmin.js <email>`                                           | Promote a user to admin                                                  |
| `node scripts/cleanupOrphanedTrackReferences.js [--dry-run]`                    | One-off/repeatable maintenance: removes references to deleted users from `Track.students`/`pendingStudents`/`pendingLeaves` |
| `node scripts/reconcileTrackCourses.js [--dry-run]`                              | One-off/repeatable maintenance: recomputes each track's `courses` array from the courses that actually point at it (`Course.track` is the source of truth) |
| `node scripts/reconcileTrackSessions.js [--dry-run]`                             | One-off/repeatable maintenance: recomputes each track's `sessions` array from the sessions that actually point at it (`Session.tracks` is the source of truth) and fixes `Session.isStandalone` |
| `node scripts/generateDashboardSnapshot.js <daily\|weekly\|monthly> [ISO date]` | Generate/refresh a dashboard-stats snapshot — meant to be cron-triggered |

### Email Diagnostic Tool

```bash
node testEmail.js your-email@example.com
```

This script verifies your `.env` variables, tests the SMTP connection, and sends a styled HTML test email.

### Admin Promotion

```bash
node scripts/createAdmin.js user@example.com
```

Promotes an existing user to admin role.

### Orphaned Track Reference Cleanup

```bash
node scripts/cleanupOrphanedTrackReferences.js --dry-run   # preview
node scripts/cleanupOrphanedTrackReferences.js              # apply
```

Scans every track's `students`, `pendingStudents`, and `pendingLeaves` arrays
for ids that no longer resolve to an existing user (a possible leftover from
before `cascade.service.js#hardDeleteUserCascade` was fixed to pull those
fields on user delete) and removes them. Safe to re-run — it's a no-op once
the data is clean.

### Track/Course Sync Reconciliation

```bash
node scripts/reconcileTrackCourses.js --dry-run   # preview
node scripts/reconcileTrackCourses.js              # apply
```

Recomputes every track's `courses` array from the courses that actually have
`track` set to it — `Course.track` is treated as the source of truth, since
that's the field `course.service.js` used to write directly before it was
fixed to keep both sides in sync (see the Roadmap entry below). Fixes any
track left out of sync from before that fix. Safe to re-run.

### Track/Session Sync Reconciliation

```bash
node scripts/reconcileTrackSessions.js --dry-run   # preview
node scripts/reconcileTrackSessions.js              # apply
```

The sessions counterpart of the script above (BACKEND-REQUESTS-2 #4.1 — a track
reporting `sessionCount: 0` while sessions are linked to it). Recomputes every
track's `sessions` array from the sessions that actually have that track in
`Session.tracks` — `Session.tracks` is treated as the source of truth because
it is the side `GET /sessions/track/:id` and enrollment already read — then
recomputes `Session.isStandalone` (standalone = in no track and no course).
It only ever sets those two fields. Safe to re-run; a no-op once clean. Run
`--dry-run` first.

### Dashboard Stats Snapshot Generation

```bash
node scripts/generateDashboardSnapshot.js daily --previous     # the day that just finished
node scripts/generateDashboardSnapshot.js weekly --previous    # last Monday-Sunday week
node scripts/generateDashboardSnapshot.js monthly --previous   # last calendar month
node scripts/generateDashboardSnapshot.js daily                # the day still in progress ("refresh now")
node scripts/generateDashboardSnapshot.js daily 2025-06-15     # backfill the period containing a specific date
```

Computes and **upserts** a `DashboardStats` snapshot for the given period (re-running for the same period/date refreshes it in place rather than duplicating). Calls the service directly — no HTTP, no auth token — so it's meant to be wired up to an OS-level cron job.

> **A scheduled job must use `--previous`.** These jobs fire a few minutes after a period starts (00:05 for daily). With no argument the script snapshots the period that _contains now_, i.e. one that has existed for five minutes and shows about zero new users, while the period that actually just ended is never recorded. `--previous` snapshots the one that just finished. (BACKEND-REQUESTS-2 #5.2. Note this explains near-zero, misleading snapshots; a `trends` list that is completely empty means the job isn't running at all — see the checks below.) `--previous` and an explicit date can't be combined.

```cron
5 0 * * *    cd /path/to/app && node scripts/generateDashboardSnapshot.js daily --previous
10 0 * * 1   cd /path/to/app && node scripts/generateDashboardSnapshot.js weekly --previous
15 0 1 * *   cd /path/to/app && node scripts/generateDashboardSnapshot.js monthly --previous
```

**In this repo, that cron trigger is `.github/workflows/dashboard-snapshots.yml`** rather than an OS-level cron — the production deployment (Render free tier) has no persistent cron of its own, so a scheduled GitHub Actions workflow runs the same three commands on the same schedule shown above, connecting directly to the production database. It needs one repo secret:

| Secret         | Value                                |
| -------------- | ------------------------------------- |
| `DATABASE_URL` | The production MongoDB connection string |

Things to check if `trends` is still empty after the schedule has had time to run:

- `package-lock.json` is committed (the workflow uses `npm ci` and npm caching, both of which fail without it).
- The workflow file is on the repository's **default branch** — GitHub only runs scheduled workflows from there.
- The `DATABASE_URL` secret exists (Settings → Secrets and variables → Actions).
- The Actions tab shows the runs, and they are green. GitHub can delay a scheduled run by several minutes, and disables schedules on a repo with no activity for 60 days (re-enable them in the Actions tab).

It can also be triggered manually from the Actions tab (`workflow_dispatch`): pick a period, and optionally a `date` (`YYYY-MM-DD`, UTC) to backfill the period containing it; leave the date blank to snapshot the period that just finished.

The same result is also reachable on-demand via `POST /v1/dashboard-stats/snapshot` (admin only), for a manual "refresh now" action from an admin UI.

---

## 🚀 Deployment Guide

### Render (Recommended)

1. Push code to GitHub.
2. Create a new **Web Service** on [Render](https://render.com/).
3. Connect your repo.
4. Set environment variables in the Render dashboard.
5. Use the following settings:
   - **Build Command:** `npm install`
   - **Start Command:** `NODE_ENV=production npm start`
   - **Health Check Path:** `/health`

### Railway

1. Install Railway CLI: `npm i -g @railway/cli`
2. Login: `railway login`
3. Link project: `railway link`
4. Add MongoDB plugin (or use Atlas).
5. Deploy: `railway up`

### Environment Checklist for Production

- [ ] `NODE_ENV=production`
- [ ] `JWT_SECRET` is strong and unique (≥ 32 chars)
- [ ] `DATABASE_URL` points to production cluster
- [ ] `FRONTEND_URL` and `BASE_URL` are set to production domains
- [ ] `EMAIL_SERVICE` is configured (Gmail, AWS SES, etc.)
- [ ] `JWT_COOKIE_EXPIRES_IN` matches your security policy
- [ ] Rate limits are appropriate for your traffic
- [ ] Database indexes exist. `autoIndex` is off, and Mongoose `syncIndexes()` runs at startup **only** when `SYNC_INDEXES=true` (and never when `NODE_ENV=test`). With the flag unset or `false`, no index is built or dropped, so declared indexes (including the `unique` ones) exist only if someone synced them earlier. `syncIndexes()` also **drops** any index not declared in a schema, so review the plan on a copy first.
- [ ] **Stage 2 index changes need an index sync.** Removing the `Course`/`Track` text indexes and replacing the activity-log `{ createdAt: -1 }` index with a 180-day TTL index only change the *code*. MongoDB itself changes when the index sync runs (`syncIndexes()`: the index sync script once it exists, until then one start with `SYNC_INDEXES=true`). Until then the text indexes stay in the database (harmless), and the TTL index is not created. MongoDB refuses two indexes on the same key with different options, so the sync must drop the old `createdAt_-1` index before creating the TTL one. `syncIndexes()` handles that, and it drops every other undeclared index too. The TTL then deletes rows older than 180 days (background task, about once a minute); the manual prune endpoint keeps working.

---

## 🧪 Testing

### Manual Testing

```bash
# Health check
curl http://localhost:5000/health

# Public endpoint
curl http://localhost:5000/v1/tracks

# Swagger UI
open http://localhost:5000/api-docs
```

### Automated Testing (Jest + Supertest)

```bash
npm test              # run the full suite once
npm run test:watch    # re-run automatically as you edit
npm run test:coverage # run once + generate a coverage report (coverage/lcov-report/index.html)
```

Tests run against a real, throwaway in-memory MongoDB **replica set** (`mongodb-memory-server`'s `MongoMemoryReplSet`) — never your real dev or production database. A replica set (rather than a plain standalone instance) is required so that the MongoDB transactions in `cascade.service.js` can actually run during tests. See **[TESTING.md](./TESTING.md)** for a full walkthrough of how the setup works and how to write your next test.

```
tests/
├── globalSetup.js        # starts the in-memory MongoDB replica set once per run
├── globalTeardown.js     # stops it once per run
├── setupAfterEnv.js      # per-file: connects Mongoose, mocks Email, clears data between tests
├── helpers/
│   ├── testUser.js       # creates a user + valid JWT without hitting /signup
│   └── fixtures.js       # shared track/course/session fixture builders
├── config/                     # mailer.config.js unit tests
├── controllers/                # endpoints not covered by the top-level *.test.js files
│   (course/session/track/weeklyTask "missing endpoints" suites)
├── services/                   # service-layer unit tests (course/session/track/
│   enrollment/weeklyTask), incl. cascade/transaction edge cases
├── utils/                      # pure-function/class tests (Email, logger, escapeHtml,
│   attachment validation)
├── auth.test.js, passwordReset.test.js         # signup/login/logout, forgot/reset/update password
├── adminUsers.test.js, bulkUser.test.js         # admin user management
├── trackCourseCRUD.test.js, trackEndpoints.test.js  # track/course CRUD + analytics/pending/leaves
├── enrollment.test.js, cascade.test.js, sessionGating.test.js
├── announcement.test.js, events.test.js, feed.test.js
├── contact.test.js, contactAdmin.test.js
├── reviews.test.js, assignments.test.js, weeklyTask.test.js
├── updateMe.test.js
├── error.controller.test.js, errorHandling.test.js, app.test.js, APIFeatures.test.js
```

66 test files span auth (incl. `rememberMe` session length), password recovery, every CRUD resource (tracks/courses/sessions/events/announcements), enrollment + the MongoDB transaction paths in `cascade.service.js`, reviews, assignments (incl. grading), weekly tasks, contact (public + admin), activity logs (audit-trail read/write + auth/role guards), dashboard stats (period-boundary math, snapshot generation/upsert, trends, prune), model-level field validators, middleware edge cases, the global error handler, and `src/app.js`'s own production-vs-development configuration. See **[TESTING.md](./TESTING.md)** for the full file-by-file coverage table and the (short) list of what's still deliberately untested — mainly that email-sending is mocked everywhere rather than asserted on, and a couple of narrow model-validator edge cases.

---

## 🗺️ Roadmap

### Implemented ✅

- [x] JWT Authentication (bearer + cookie)
- [x] Role-based access control
- [x] Track / Course / Session CRUD
- [x] Enrollment with prerequisites & access rules
- [x] Events & RSVP
- [x] Announcements with pinning
- [x] Dashboard feed
- [x] Bulk user actions
- [x] Track analytics
- [x] Session enrollment lookup by student (`GET /v1/sessions/student/:studentId`, matching Track/Course)
- [x] Email service (welcome, password reset)
- [x] Swagger documentation
- [x] Public contact form (stored + admin email notification)
- [x] Contact form admin management — admins can list, view, and update a submission's status (`new` / `read` / `archived`)
- [x] Track reviews (enrolled-student ratings & feedback) — extended to also cover courses and sessions
- [x] Review deletion — the review's own author, or an admin, can remove it
- [x] Assignments — full CRUD (create/update/delete) for owner instructor or admin, at the course and standalone-session level
- [x] Assignments list — track (aggregated), course, and standalone-session level (`GET .../assignments`, each with per-user submission status)
- [x] Weekly tasks — per-course buckets of items (reading/quiz/video/etc.) with per-student completion tracking, aggregated at the track level; full CRUD (create/update/delete) plus per-item completion toggling
- [x] Assignment submissions — students submit/resubmit work (`POST /assignments/:id/submissions`), with a computed `late` flag
- [x] Assignment grading — owner instructor / admin grades a submission (`PATCH /assignments/:id/submissions/:studentId/grade`)
- [x] MongoDB Transactions for cascade enrollment operations (`cascade.service.js`)

* [x] Request Correlation IDs — full implementation with `AsyncLocalStorage`, automatic injection into every log, and `X-Request-ID` round-trip to clients

- [x] Jest + Supertest test setup — in-memory MongoDB **replica set** (enabling real transaction tests), shared fixture builders, a global Email mock, and 66 test files covering auth, password recovery, every CRUD resource, enrollment + cascade transactions, reviews, assignments, weekly tasks, contact, activity logs, dashboard stats, model validators, middleware edge cases, the global error handler, and `app.js` config (see [TESTING.md](./TESTING.md) for the full breakdown)
- [x] **Activity Logs** (`activityLog.model.js` / `activityLog.service.js`) — server-written audit trail (no public create endpoint), self-service "my activity" timeline, admin listing/per-user lookup/aggregated summary, and retention pruning
- [x] **Admin Analytics Dashboard** (`dashboardStats.model.js` / `dashboardStats.service.js`) — live on-demand stats plus persisted, upsertable daily/weekly/monthly snapshots for trend charts, a cron-friendly CLI generator (`scripts/generateDashboardSnapshot.js`), and retention pruning
- [x] **Announcement audience filtering** — `GET /v1/announcements` now filters by `audience`/`targetTrack`/`targetCourse`: everyone sees `audience: 'all'`, plus `'track'`/`'course'`-targeted announcements for a track/course they're enrolled in; the creating instructor can also see their own targeted announcement regardless of enrollment; admins see everything
- [x] **Track/session detach unenrollment** — removing a course or session from a track (short of deleting the track) now unenrolls that track's current students from it, mirroring the auto-enroll on add (see [Enrollment Cascade Rules](#-database-overview))
- [x] **`rememberMe` login sessions** — `POST /v1/users/login` accepts an optional `rememberMe` boolean that sizes both the JWT and the `jwt` cookie to ~30 days (`true`) or ~1 day (`false`/omitted), independent of the `JWT_EXPIRES_IN`/`JWT_COOKIE_EXPIRES_IN` defaults still used by every other auth flow
- [x] **`pendingTrack` on `/users/me`** — the authenticated user response now includes `pendingTrack` (the `_id` of a track awaiting approval, or `null`), computed from the existing `Track.pendingStudents` source of truth rather than a new stored field
- [x] **Session "watched" progress tracking** — `PUT /v1/sessions/:id/progress` (enrolled students only) marks a session watched for the current user; `GET /v1/sessions/:id` returns `myProgress: { status, watchedAt }` for enrolled callers. Implemented as an embedded `Session.progress` array, atomically updated (mirrors the weekly-task completions pattern) so the raw per-student list is never exposed — only the caller's own status.
- [x] **Public track session catalog** — `GET /v1/tracks/:id/session-catalog` (no auth) lets prospective students preview a track's sessions (`title`, `description`, `startDate`, `duration` only — no media/URLs) before enrolling.
- [x] **Admin-assignable track instructor** — `POST /v1/tracks` / `PATCH /v1/tracks/:id` accept an `instructor` field for admins (validated against the target user's role), while non-admins still always default to their own id.
- [x] **User search & active-status filtering** — `GET /v1/users?search=` matches name/email (case-insensitive); `?active=false` / `?includeInactive=true` lets admins find and reactivate deactivated accounts, which were previously permanently hidden from this endpoint regardless of query params.
- [x] **Session title minimum length** — `POST`/`PATCH /v1/sessions` now requires a 3+ character title, matching the constraint assignment titles already had.
- [x] **Staff access to submitted work** — `GET /v1/assignments/:id` (owner instructor/admin) returns the assignment with its submissions attached (`hasFile` instead of the raw URL), and `GET /v1/assignments/:id/submissions/:studentId/file` redirects to the actual file — the one path that ever exposes it. Previously staff had no way to open a student's submitted work at all.
- [x] **Grading feedback** — `PATCH /v1/assignments/:id/submissions/:studentId/grade` accepts an optional `feedback` string (up to 2000 characters) alongside the grade; both are returned in the student's `mySubmission`. Resubmitting clears prior grade *and* feedback, since both were written against the old file.
- [x] **Review author populated on create** — `POST /tracks|courses|sessions/:id/reviews` now returns `user` populated (`_id`, `name`, `photo`), matching the shape the list (`GET .../reviews`) endpoints already returned.
- [x] **`mostActiveTrack` populated on live stats** — `GET /v1/dashboard-stats/live` now returns `mostActiveTrack: { _id, title }` like every stored-snapshot endpoint already did, instead of a bare ObjectId.
- [x] **Scheduled dashboard-stats snapshots** — `.github/workflows/dashboard-snapshots.yml` runs `scripts/generateDashboardSnapshot.js` on the daily/weekly/monthly cadence the script already documented; previously nothing called it on a schedule, so `GET /v1/dashboard-stats/trends` was always empty. Needs a `DATABASE_URL` repo secret; also triggerable manually via `workflow_dispatch`.
- [x] **Full cascade cleanup on user delete** — `cascade.service.js#hardDeleteUserCascade` now also pulls a deleted user from `Track.pendingStudents` and `Track.pendingLeaves` (previously only `Track.students` was cleaned up, which is exactly how stale pending entries could accumulate — see `scripts/cleanupOrphanedTrackReferences.js`), plus their own `Session.progress` entry.
- [x] **`GET /tracks/:id/pending` includes leave requests** — now returns `pendingStudents` *and* `pendingLeaves` together, so the frontend doesn't need a second call to `GET /tracks/:id/leaves` (which still works standalone) just to show both in one view.
- [x] **Course/track sync on create and update** — `POST /courses` and `PATCH /courses/:id` now route a `track` field through the same `trackService.addCourseToTrack`/`removeCourseFromTrack` functions the dedicated `/tracks/:trackId/courses/:courseId` endpoints already used, instead of writing `course.track` directly. Previously `Track.courses` could silently fall out of sync with which courses actually point at it. Detaching (`track: null`) enforces the same "a track needs at least one course or session" guard the dedicated `DELETE` endpoint has; attaching/detaching either way requires owning the target track (or being admin) — closing an authorization gap the old direct-write path didn't check either. `scripts/reconcileTrackCourses.js` backfills any tracks already desynced from before this fix.
- [x] **Draft visibility, everywhere (BACKEND-REQUESTS-2 stage 1)** — a new `src/services/policy.service.js` is now the one place "can this caller see this draft?" is decided. Closes the gap where `GET /sessions/track/:trackId` (and `/sessions/instructor/:id`, `/sessions/student/:id`) applied **no** draft filtering or content redaction at all — a `published: false` session's `url`, `embedUrl`, `resources`, and even the raw per-student `progress` array could reach a student through those endpoints even though `GET /sessions/:id` was already gated. `GET /sessions/:id` itself gained the same "404, not redacted" rule `GET /tracks/:id` and `GET /courses/:id` already had, and the bare list endpoints (`GET /sessions`, `GET /tracks`, `GET /courses`) now exclude drafts the caller isn't authorized for instead of returning every record regardless of `published`. An admin or the resource's current `instructor` always sees their own drafts.
- [x] **`createdBy` attribution field (BACKEND-REQUESTS-2 stage 3, Q6)** — `Assignment` and `WeeklyTask` gained a `createdBy` field, set once at creation alongside (and equal to, today) `instructor`. It is pure historical attribution: no authorization check reads it, it's not accepted from any request body (Joi rejects the unknown key outright, 400), and it's `nullable`/not `required` since existing records predate it. `scripts/backfillCreatedBy.js` fills `createdBy = instructor` for any pre-existing record missing it — idempotent, `--dry-run` supported, never overwrites an existing value, safe to re-run — **not executed** as part of this delivery, ready whenever that's decided separately. This decouples the two concepts ahead of stage 4, where `instructor`'s authorization role gets extended to co-instructors without `createdBy` needing to move.
- [x] **Public membership-array reduction (BACKEND-REQUESTS-2 stage 2, Q7)** — a non-staff caller no longer receives the raw `students` array (Track/Course/Session) or `pendingStudents`/`pendingLeaves` (Track) — those keys are now simply absent from their response, replaced with `studentCount` (always present) and `isEnrolled`/`isPending`/`isPendingLeave` (the requester's own status). This closes three real leaks, not just a style change: `GET /tracks`/`GET /courses` (list) previously returned every record's raw membership arrays to any caller including anonymous; `GET /tracks/:id`'s `pendingStudents`/`pendingLeaves` had **no gate at all** — even a random enrolled student could see who else had applied to join or leave; and `GET /tracks/popular`'s aggregation pipeline bypassed the usual Mongoose serialization entirely and leaked the same arrays on a fully public endpoint. `policy.service.js` gained `isMemberOf`/`redactMembership` for this. **Intentional breaking API change** — see the callout in API.md above the Tracks section. The two course sub-lists that were deferred here are done in the carry-over entry below.
- [x] **YouTube added to the trusted-host allowlist, one list to rule them all** — `src/utils/trustedHosts.js` now includes `youtube.com` / `youtu.be` / `youtube-nocookie.com` (subdomains like `www.`/`m.` are covered automatically). `Session.url`'s old hardcoded youtube/drive regex fast-path (which also quietly allowed non-`https` URLs) is gone — every URL field in the app, Mongoose- or Joi-validated, now goes through the exact same `isTrustedHost()` check. The list is also served at `GET /v1/config/trusted-hosts` so a form can warn about an untrusted host before submitting instead of only finding out from a 400.
- [x] **Staff submission counts (BACKEND-REQUESTS-2 stage 5, #3.2)** — the three assignment list endpoints (`/tracks|courses|sessions/:id/assignments`) now add `submissionCount` and `ungradedCount` for staff of each assignment (an admin, or the assignment's own instructor), so the Studio no longer needs one `GET /assignments/:id` per assignment to draw "3 submissions · 2 to grade". Counts only; students and non-managing instructors never get them, and the raw `submissions` array is still never sent. Stage 4 will swap the "is staff" check for the policy-service management rule in one place (`assignment.service.js#isAssignmentStaff`).
- [x] **Co-instructors & current-authorization permissions (BACKEND-REQUESTS-2 stage 4, §2, Q3/Q10)** — `Track.instructors` (co-instructors, admin-set, returned as `{ _id, name, photo }`); admin-only `instructor` on courses and sessions; `GET /tracks?instructor=` (lead or co-instructor); one management policy in `policy.service.js` replacing creator-based `checkOwnership` for tracks/courses/sessions/assignments/weekly tasks (no creator override); admin-only `POST /tracks`, track deletion and instructor changes; link/unlink rules; `leaves`/`analytics` gated; drafts follow the same rule; staff counts use the policy. Breaking changes are listed in API.md. The carry-over sub-lists are the entry below.
- [x] **Carry-over: sub-list draft filter + redaction (BACKEND-REQUESTS-2 stage 4b, Q5/Q7)** — `GET /courses/instructor/:id`, `/courses/track/:id`, `/courses|tracks|sessions/student/:id` and `GET /users/me/enrollments` now apply the draft filter (published only; staff also get drafts they manage; admins all) and the membership redaction (`studentCount`/`isEnrolled`/`isPending`). A student's enrolled-but-unpublished content is hidden from lists. `GET /tracks/:id/session-catalog` is published-only. Breaking changes: see API.md. `session.route.js`'s global `protect` is unchanged (open question in STAGE_PLAN.md).
- [x] **Submissions are links — documented, and the error says so (stage 5, #3.1, Q1)** — no behavior change to what is accepted (links were already the only format); a multipart upload used to come back as the baffling `"file" is required`, and now returns a message explaining submissions are links. Every "trusted host" error message (Joi attachment/submission validators and the Mongoose session/course/event/announcement/assignment validators) is now built from `src/utils/trustedHostsMessage.js`, which reads the one real allowlist — so the text lists every allowed host and can't drift from what is enforced (the old hand-typed lists had already omitted Discord's CDN). Swagger and API.md state the link-only design; Cloudinary remains an unimplemented future option.
- [x] **Track ↔ session/course links stay in sync (stage 5, #4.1/#4.2)** — `addCourseToTrack`/`addSessionToTrack`/`removeCourseFromTrack`/`removeSessionFromTrack` no longer load two documents, mutate them and `.save()` both; that could leave a link half-written (notably when one document failed whole-document validation after the other had already saved — e.g. a legacy session with a now-invalid URL) and could never be repaired through the API. They now use atomic, idempotent `$addToSet`/`$pull`, write the child side first, and **repair** a one-sided link instead of erroring (a fully linked pair is still a 400). Removing a course no longer detaches or unenrolls it if it actually belongs to a different track, and adding a course now detaches it from *every* other track that still listed it. `deleteTrackCascade` works from the union of both sides, so deleting an already-desynced track still detaches every child. New `scripts/reconcileTrackSessions.js` (idempotent, `--dry-run`) repairs records that are already out of sync — **not executed**.
- [x] **`active` on admin user listings (BACKEND-REQUESTS-2 stage 6, #5.1)** — `GET /v1/users` (including `?includeInactive=true`, `?active=false` and `?fields=`) and `GET /v1/users/:id` now always return an explicit `active` boolean, so an admin list can show who is deactivated. `active` is `select: false` on the schema, which is why it used to vanish; `getAllUsers` already re-selected it and `getUserById` now does too. Covered by tests so it can't silently regress.
- [x] **Scheduled dashboard snapshots now record the period that just finished (stage 6, #5.2)** — the 00:05 UTC job was snapshotting the period containing _now_ (five minutes old, ~zero new users) and never the one that had just ended. `scripts/generateDashboardSnapshot.js` gained `--previous` (backed by the new, unit-tested `dashboardStatsService.getPreviousPeriodDate`), and `.github/workflows/dashboard-snapshots.yml` uses it for every scheduled run and for manual runs without a date. Manual runs also accept an optional, validated `date` for backfills, and workflow inputs are now passed through environment variables instead of being interpolated into shell.
- [x] **Stage 1 cleanup: lighter auth, honest comments (PLAN 1.2/1.3)** — `protect` and `optionalAuth` are idempotent (a second one in the same request skips the token check and the user read, so `GET /sessions` reads the user once), and neither loads `photo` any more (`GET /users/me`, `PATCH /users/me` and the admin user endpoints still return it from their own reads). `GET /users/me` now runs its user read and its pending-track lookup together. `GET /sessions` no longer populates every session's roster just to compare ids. **Breaking:** `POST /users/bulk` accepts at most 100 `userIds` (101 or more → `400`). Comments about the rate-limit `max` option, the cookie `sameSite` setting and the index-sync step were corrected; behaviour is unchanged.
- [x] **Stage 2: bounded request path (PLAN 2.1 to 2.6)** — the Brevo call has a 5 s deadline (`AbortSignal.timeout`), and the welcome, enrollment-confirmation and contact-notification emails are started without being awaited (`src/utils/runInBackground.js` logs a failure with an id, never an address or body); the password reset email is still awaited. Audit rows are written with `recordActivity`, which does not block the response. List and search queries built by `APIFeatures` carry `maxTimeMS` 10 000 (dashboard snapshot queries 60 000), and the count now runs alongside the page query. The unused `Course`/`Track` text indexes are removed, the activity-log `createdAt` index is now a 180-day TTL index, and a deactivated user can no longer be assigned as an instructor (`400`). See the deploy notes below.

### Planned 🔮

- [ ] **`logActivity` coverage is uneven across domain services** — most services (tracks, courses, sessions, events, announcements, assignments, weekly tasks, reviews) already call `activityLog.service.js#logActivity` for _some_ of their mutations (e.g. create/update/delete), but not consistently for every exported action — e.g. `course.service.js` has 13 exported functions but only 4 `logActivity` call sites. `cascade.service.js`, `contact.service.js`, and `dashboardStats.service.js` don't call it at all yet. Auditing every mutating function for a missing log call is the remaining work, not wiring the feature up from scratch.
- [ ] **Email verification flow** — the `emailVerified` flag exists and resets on email change, but there's no self-service send/verify-token endpoint yet; currently only an admin can flip it
- [ ] **Late assignment submissions are accepted, not blocked** — `submitAssignment` computes and returns a `late: submission.submittedAt > assignment.deadline` flag, but nothing currently prevents a submission after the deadline. This is a soft deadline by (undocumented) default; whether it should stay that way, become a hard block, or get a grace-period window is a product decision, not a bug.
- [ ] **Hard-delete cascade for users blocks rather than reassigns** — `hardDeleteUserCascade` currently returns 409 if the user is the required instructor/creator of any Course, Track, Event, Announcement, Session, Assignment, or WeeklyTask, rather than reassigning or nulling those references. Safe, but inflexible — an admin can't hard-delete a former instructor without first manually reassigning their content elsewhere.
- [ ] **Structured error codes on `AppError`** — errors currently carry only a `message` string; the frontend can't reliably branch on error _type_ without string-matching messages. Adding a `code` field (e.g. `PREREQUISITE_NOT_MET`) would make that robust.
- [ ] **`search()` uses regex instead of the `text` indexes that already exist** — `Track`/`Course` both define MongoDB `text` indexes, but `APIFeatures.js#search()` builds a `$regex` `$or` query, which can't use them. Fine at current data volume; would need attention if search performance ever becomes a problem.
- [ ] **Webhook Support** for external integrations (Discord, Slack)
- [ ] **Full test coverage** — still need tests
- [ ] **Open: anonymous browsing of public sessions** — `session.route.js` keeps its global `protect`; see the open question in `STAGE_PLAN.md`.
- [ ] **Session list routes require authentication even for public content** — `session.route.js` applies `router.use(protect)` before every route, including `GET /sessions` (which also has `optionalAuth`, currently unreachable dead code since `protect` already ran). `track.route.js`/`course.route.js` don't have this restriction. Worth a decision: should published, `access: 'public'` sessions be anonymously browsable the way tracks/courses are, given self-enrollment implies previewing before enrolling?

---

## 🚑 Troubleshooting

### "Cannot connect to MongoDB"

- Verify `DATABASE_URL` is correct.
- If using Atlas, whitelist your IP in Network Access.
- If using local MongoDB, ensure `mongod` is running.

### "CORS error from frontend"

- Add your frontend URL to `FRONTEND_URL`.
- In development, `http://localhost:3000` is already whitelisted.

### "Emails not sending"

- Run `node testEmail.js your@email.com` to diagnose.
- Check Mailtrap inbox (dev) or Gmail dashboard (prod).
- Verify `EMAIL_USER` and `EMAIL_PASS` are correct.

### "Swagger UI not loading / YAML errors"

- Ensure JSDoc indentation is consistent in `src/routes/*.js`.
- Avoid `description: | text-on-same-line` — use inline strings or proper multi-line blocks.
- Run `npm start` and check the console for `swagger-jsdoc` parse errors.

### "Invalid token" after password change

- This is by design. Changing your password invalidates existing JWTs via `passwordChangedAt`.
- Simply log in again to receive a new token.

---

## 🤝 Contributing

Contributions are welcome! This is an educational project, but we follow clean code principles.

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Code Style

- Use **async/await**; avoid callbacks.
- Use **camelCase** for variables and functions.
- Use **PascalCase** for models and classes.
- Always wrap async route handlers with `catchAsync`.
- Never trust `req.body` — validate with Joi and strip sensitive fields in controllers.

---

## 👤 Author

**Basem Esam Omar**  
Backend Engineer — Node.js | MongoDB | Express.js  
[GitHub](https://github.com/basem3sam) · [LinkedIn](https://linkedin.com/in/basemesam)

---

## 📄 License

[ISC License](LICENSE) — Free for educational use.

> **Disclaimer:** This project was built for the Trosc Student Club at Suez Canal University. It is intended for educational and non-commercial use. Use at your own risk in production environments.
